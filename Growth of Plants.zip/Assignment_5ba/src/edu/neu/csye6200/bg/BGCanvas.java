package edu.neu.csye6200.bg;


import java.util.logging.Logger;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Line2D;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * A sample canvas that draws a rainbow of lines
 * @author MODALAANUSHA
 */
public class BGCanvas extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private Logger log = Logger.getLogger(BGCanvas.class.getName());
    private int lineSize = 20;
    private Color col = null;
    private long counter = 0L;
    public int maxGen=0;
    public int ruleNum=0;
    private int width;
    private int height;
    public int times=-2;
    private BGGenerationset bgGenSet = null;
    public boolean done = false;
    public int i1 = 0;
    public Thread thread1 = null;
	private boolean isPaused = false;
	private boolean isBack = false;
	public boolean isFull = false;
    /**
     * CellAutCanvas constructor
     */
	public BGCanvas(int width, int height) {
		col = Color.WHITE;
		this.width=width;
		this.height=height;
		
	}

	/**
	 * The UI thread calls this method when the screen changes, or in response
	 * to a user initiated call to repaint();
	 */

	public void startApp(int rule,String genNum) {
		try{maxGen=Integer.parseInt(genNum);}
		catch(NumberFormatException e){}
		ruleNum=rule;
		
		i1 = 0;
		isPaused = false;
		isBack = false;
		isFull = false;
		//Creating Runnable and starting the thread
		Runnable run1 = new Runnable() {
	    public void run() {
	   while( i1 < 11) {
	   look();
		repaint();
		try {
            Thread.sleep(1000);
         } catch (InterruptedException e) {
            e.printStackTrace();
         }
		i1++;
		}
	      }
		};
		thread1 = new Thread(run1);
		thread1.start();
	}
	
	/*Checking for start, stop button click and
	waiting the thread if stop button is clicked*/
	public synchronized void look(){
		   while(isPaused)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	//for stopping the thread
	public synchronized void stop1() {
		isPaused = true;
		isBack = false;
	}
	
	//continuing thread
	public synchronized void cont() {
		isPaused = false;
		
		if(isBack == true)
		i1++;
		
		notifyAll();
		isBack = false;
	}
    
    //back thread
    public void back() {
    	isBack = true;
		i1--;
		repaint();
	}
    
	/**
	 * Draw the CA graphics panel
	 * @param g
	 */
	public void paint(Graphics g) {
		
		Graphics2D g2d = (Graphics2D) g;
		Dimension size = getSize();
		
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, size.width, size.height);
		g2d.setColor(Color.RED);
		g2d.drawString("Anusha Modala", 10, 15);
		g2d.drawString("001790650", 15, 28);
		bgGenSet = new BGGenerationset();
		bgGenSet.CreateGeneration(ruleNum, maxGen, size.width, size.height);
		int i = 0;	
		float width1 = 10;
		
		if(i1==10) {
		/*If the generation is completed fill this attribute
		*and back,Continue buttons will be disabled
		*/	
			isFull = true;
		}
		//Looping the Bggeneration set to create different generations
		if(bgGenSet != null) {
			
			    for(int i2=0; i2 < i1; i2++) {
			  	 BGGeneration bggen = new BGGeneration();
			  	 bggen = bgGenSet.getBgGenList().get(i2);
			     for(BGStem stem: bggen.getBglist()) {
	   			   int redVal = validColor(139-i*5);
	   			   int greenVal = validColor(69+i*5);
	   			   int blueVal = validColor(19-(i*5));
	   			   col = new Color(redVal, greenVal, blueVal);
	    		  Shape l = new Line2D.Double(stem.getStartPt()[0], stem.getStartPt()[1],
	    			stem.getEndPt()[0], stem.getEndPt()[1]);
	    		  g2d.setColor(col);
	    		  BasicStroke base = new BasicStroke(width1);
	    		  g2d.setStroke(base);
	    		  g2d.draw(l);
	    		  width1 = (float) (width1*0.97);
	    		  i++;
	    	     }
			     }
		}
		g2d.translate(size.width, size.height);
		g2d.scale(1, -1);
		}
		
	
	/*
	 * A local routine to ensure that the color value is in the 0 to 255 range.
	 */
	private int validColor(int colorVal) {
		if (colorVal > 255)
			colorVal = 255;
		if (colorVal < 0)
			colorVal = 0;
		return colorVal;
	}
	

	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		times++;
	}

	
}


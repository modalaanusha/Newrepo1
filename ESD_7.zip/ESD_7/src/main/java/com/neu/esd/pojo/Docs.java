package com.neu.esd.pojo;
public class Docs {
	
	String web_url;
	String snippet;
	String blog;
	String source;
	String multimedia;
	String headline;
	String keywords;
	String pub_date;
	String doc_typ;
	String new_des;
	String by_line;
	String tom;
	String id;
	int word_Cnt;
	String score;
	String uri;
	
	public String getWeb_url() {
		return web_url;
	}
	public void setWeb_url(String web_url) {
		this.web_url = web_url;
	}
	public String getSnippet() {
		return snippet;
	}
	public void setSnippet(String snippet) {
		this.snippet = snippet;
	}
	public String getBlog() {
		return blog;
	}
	public void setBlog(String blog) {
		this.blog = blog;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getMultimedia() {
		return multimedia;
	}
	public void setMultimedia(String multimedia) {
		this.multimedia = multimedia;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getPub_date() {
		return pub_date;
	}
	public void setPub_date(String pub_date) {
		this.pub_date = pub_date;
	}
	public String getDoc_typ() {
		return doc_typ;
	}
	public void setDoc_typ(String doc_typ) {
		this.doc_typ = doc_typ;
	}
	public String getNew_des() {
		return new_des;
	}
	public void setNew_des(String new_des) {
		this.new_des = new_des;
	}
	public String getBy_line() {
		return by_line;
	}
	public void setBy_line(String by_line) {
		this.by_line = by_line;
	}
	public String getTom() {
		return tom;
	}
	public void setTom(String tom) {
		this.tom = tom;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getWord_Cnt() {
		return word_Cnt;
	}
	public void setWord_Cnt(int word_Cnt) {
		this.word_Cnt = word_Cnt;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	
	

}

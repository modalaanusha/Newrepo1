package com.neu.esd.dao;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.neu.esd.pojo.Job;




public class JobDao extends DAO {
	public Job postJob(String industry, String jobTitle, String jobFunction,
			String jobDescription,String companyName,String city,
			String state, String street)
	        throws Exception {
	    try {
	        begin();
	        System.out.println("inside DAO");
	        
	       //PersonDao personDao=new PersonDao();
	        
	        Job job=new Job();
	        job.setIndustry(industry);
	        job.setJobDescription(jobDescription);
	        job.setJobFunction(jobFunction);
	        job.setJobTitle(jobTitle);
	        job.setCompanyName(companyName);
	        job.setDate(new Date());
	        job.setCity(city);
	        job.setState(state);
	        job.setStreet(street);
	    	getSession().save(job);
	        
	        commit();
	        return job;
	    } catch (HibernateException e) {
	        rollback();
	        throw new Exception("Exception while posting job: " + e.getMessage());
	    }
	}
	
	public List<Job> getjobs() throws Exception {
	    try {
	        begin();
	        System.out.println("inside DAO");
	        begin();
            Query q = getSession().createQuery("from Job");
            List list = new ArrayList<Job>();
            list = q.list();
            System.out.print("dao1");
            commit();
            return list;
	        
	    } catch (HibernateException e) {
	        rollback();
	        throw new Exception("Exception while fetching jobs: " + e.getMessage());
	    }
	}

	public Job getjobbyid(long jobid) throws Exception {
		// TODO Auto-generated method stub
		try {
	        begin();
	        System.out.println("inside DAO");
	        begin();
	        Query q = getSession().createQuery("from Job where id = :Id");
            q.setLong("Id", jobid);
           
            Job job = (Job) q.uniqueResult();
            System.out.print("dao1");
            commit();
            return job;
	        
	    } catch (HibernateException e) {
	        rollback();
	        throw new Exception("Exception while fetching job by id: " + e.getMessage());
	    }
	}


	
	
}
	
	
	


package com.neu.anu;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.dao.JobDao;
import com.neu.esd.pojo.Docs;
import com.neu.esd.pojo.Job;



@Controller
public class RedirectionController {
	
	@RequestMapping(value="reg.htm", method=RequestMethod.GET)
	public String re(@ModelAttribute("job")Job job,BindingResult result){
		return "Postajob";
	}
	
	@RequestMapping(value="/jobdetails/{jobid}", method=RequestMethod.GET)
	public String initializeForm(@PathVariable("jobid") long jobid,
			HttpServletRequest request,HttpSession session) throws Exception {
		try{
			System.out.println("fetced jobid" +jobid);
			JobDao jd = new JobDao();
			Job job = jd.getjobbyid(jobid);
			System.out.println("job");
			System.out.println(job.getJobTitle());
			System.out.println(job.getJobDescription());
			session.setAttribute("jobbyid", job);
			System.out.println(job.getCompanyName());
			String url="https://api.nytimes.com/svc/search/v2/articlesearch.json?query="+job.getCompanyName()+"&format=json&api-key=175f09d849cc4e278c5b9f2000fefe29";
			
			   HttpGet get=new HttpGet(url);
			
			    	            HttpClient client1 = HttpClients.createDefault();
			    	            ResponseHandler<String> responseHandler=new BasicResponseHandler();
			    	            String responseBody = client1.execute(get, responseHandler);
			    	            try {
									JSONObject resp=new JSONObject(responseBody);
									System.out.println(resp);
									JSONObject respos = resp.getJSONObject("response"); // get data object
									JSONObject meta =  respos.getJSONObject("meta");
									int hits = meta.getInt("hits"); // get the name from data.
									System.out.println(hits);
									ArrayList<Docs> Doclist= new ArrayList<Docs>();
									JSONArray docsarr =  (JSONArray)respos.get("docs");
								    
									ArrayList<Docs> docli = new ArrayList<Docs>();
					    	
									for(int i =0; i < docsarr.length(); i++)
									  {
									    JSONObject J1 = docsarr.getJSONObject(i);
									    String web_url = J1.getString("web_url");
									  
									   String main = J1.getJSONObject("headline").getString("main");
									    
							
									    
									    Docs dc = new Docs();
									   
									    dc.setHeadline(main);
									    
									   dc.setWeb_url(web_url);
									    
									    docli.add(dc);
									    
									  }
								    	
									session.setAttribute("doclist", docli);
			
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								
								}			
		
		}catch(Exception e){
				System.out.println("Exception: " + e.getMessage());
			}
		return "viewjob";
	}
	
	
	
@RequestMapping(value="/jobpost",method = RequestMethod.POST)
protected String doSubmitAction(@ModelAttribute("job") Job jobs, BindingResult result,HttpSession session
		,HttpServletRequest request,Model model) throws Exception {
	
	try{
	JobDao jd=new JobDao();
	
	Job jobs1 = jd.postJob(jobs.getIndustry(),jobs.getJobTitle(), 
		    jobs.getJobFunction(), jobs.getJobDescription(),
			jobs.getCompanyName(),jobs.getCity(), jobs.getState(), jobs.getStreet());
	
	@SuppressWarnings("unchecked")
	List<Job> Joblist = (List<Job>) session.getAttribute("jobsli");
	Joblist.add(jobs1);
	session.setAttribute("jobsli", Joblist);
	return"index";
	}catch(Exception e){
		System.out.println("Exception: " + e.getMessage());
	}
	return "errorjob";
}
}



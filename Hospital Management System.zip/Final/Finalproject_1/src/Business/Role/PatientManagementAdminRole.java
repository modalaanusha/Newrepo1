/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

/**
 *
 * @author anusha_m
 */
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.DoctorOrganization;
import Business.Organization.NurseOrganization;
import Business.Organization.Organization;
import Business.Organization.PatientManagementOrganization;
import Business.UserAccount.UserAccount;
//*import UserInterface.DoctorRole.DoctorWorkAreaJPanel;
import javax.swing.JPanel;
import userinterface.Nurse.NurseWorkAreaJPanel;
import userinterface.PatientManagementAdmin.PatientAdminJPanel;
public class PatientManagementAdminRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel pnl, UserAccount ua, Organization o, 
    Enterprise e, EcoSystem es) {
       return new PatientAdminJPanel(pnl,ua,(PatientManagementOrganization)o,e);
    }
}

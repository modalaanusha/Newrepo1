/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import java.util.Date;

/**
 *
 * @author anusha_m
 */
public class VitalSign {
    private int resprate;
    private int heartrate;
    private int bloodpres;
    private float weight;
    private Date timestamp;

    public int getResprate() {
        return resprate;
    }

    public void setResprate(int resprate) {
        this.resprate = resprate;
    }

    public int getHeartrate() {
        return heartrate;
    }

    public void setHeartrate(int heartrate) {
        this.heartrate = heartrate;
    }

    public int getBloodpres() {
        return bloodpres;
    }

    public void setBloodpres(int bloodpres) {
        this.bloodpres = bloodpres;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return timestamp.toString();
    }

    

     
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import java.util.Date;

/**
 *
 * @author anusha_m
 */
public class Patient{
 
    private String PatientName;
    private int patientid;
    private int age;
    private String pridoctor;
    private String prefpharm;
    private String insid;
    private Date validdate;
    private int floor;
    private int room;
    private int days;
    private int insamount;
    private int billamount;
    private int totalamount;
    private VitalSignHistory vitalSignHistory;
    private LabTestResultsHistory ltrh;
    public static int counter;
    public Patient(){
        this.vitalSignHistory = new VitalSignHistory();
        this.ltrh = new LabTestResultsHistory();
        patientid = counter;
        ++counter;
    }

    public VitalSignHistory getVitalSignHistory() {
        return vitalSignHistory;
    }

    public void setVitalSignHistory(VitalSignHistory vitalSignHistory) {
        this.vitalSignHistory = vitalSignHistory;
    }

    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String PatientName) {
        this.PatientName = PatientName;
    }

    public int getPatientid() {
        return patientid;
    }

    public void setPatientid(int patientid) {
        this.patientid = patientid;
    }

    public String getInsid() {
        return insid;
    }

    public void setInsid(String insid) {
        this.insid = insid;
    }

    public Date getValiddate() {
        return validdate;
    }

    public void setValiddate(Date validdate) {
        this.validdate = validdate;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getInsamount() {
        return insamount;
    }

    public void setInsamount(int insamount) {
        this.insamount = insamount;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPridoctor() {
        return pridoctor;
    }

    public void setPridoctor(String pridoctor) {
        this.pridoctor = pridoctor;
    }

    public String getPrefpharm() {
        return prefpharm;
    }

    public void setPrefpharm(String prefpharm) {
        this.prefpharm = prefpharm;
    }

    public LabTestResultsHistory getLtrh() {
        return ltrh;
    }

    public void setLtrh(LabTestResultsHistory ltrh) {
        this.ltrh = ltrh;
    }

    public int getBillamount() {
        return billamount;
    }

    public void setBillamount(int billamount) {
        this.billamount = billamount;
    }

    public int getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(int totalamount) {
        this.totalamount = totalamount;
    }
    
     @Override
    public String toString() {
        return PatientName;
    }
}



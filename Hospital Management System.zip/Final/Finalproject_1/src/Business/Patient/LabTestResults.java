
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import java.util.Date;

/**
 *
 * @author anusha_m
 */
public class LabTestResults{
    private int RBC;
    private int WBC;
    private String HepaTest;
    private String JaundiceTest;
    private int SugarLevel;
    private String result;

    public int getRBC() {
        return RBC;
    }

    public void setRBC(int RBC) {
        this.RBC = RBC;
    }

    public int getWBC() {
        return WBC;
    }

    public void setWBC(int WBC) {
        this.WBC = WBC;
    }

    public String getHepaTest() {
        return HepaTest;
    }

    public void setHepaTest(String HepaTest) {
        this.HepaTest = HepaTest;
    }

    public String getJaundiceTest() {
        return JaundiceTest;
    }

    public void setJaundiceTest(String JaundiceTest) {
        this.JaundiceTest = JaundiceTest;
    }

    public int getSugarLevel() {
        return SugarLevel;
    }

    public void setSugarLevel(int SugarLevel) {
        this.SugarLevel = SugarLevel;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    
}



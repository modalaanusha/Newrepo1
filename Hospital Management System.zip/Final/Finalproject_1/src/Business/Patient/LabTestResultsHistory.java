/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import java.util.ArrayList;

/**
 *
 * @author anusha_m
 */
public class LabTestResultsHistory {
    private ArrayList<LabTestResults> LabResultsList;

    public LabTestResultsHistory() {
        LabResultsList = new ArrayList<LabTestResults>();
    }

    public ArrayList<LabTestResults> getLabResultsList(){
        return LabResultsList;
    }
    
    public LabTestResults addLabTestResults()
    {
     LabTestResults ltr = new LabTestResults();
     LabResultsList.add(ltr);
     return ltr;
    }
    
    public void removeLabTest(LabTestResults ltr)
    {
     LabResultsList.remove(ltr);
    }

    
    
}

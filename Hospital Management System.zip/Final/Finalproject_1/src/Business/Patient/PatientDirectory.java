/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import Business.Employee.Employee;
import java.util.ArrayList;

/**
 *
 * @author anusha_m
 */
public class PatientDirectory {
  private ArrayList<Patient> patientsList;
    
    public PatientDirectory(){
        patientsList=new ArrayList<>();
    }

    public ArrayList<Patient> getListofPatients() {
        return patientsList;
    }

    public void deletePatient(Patient patientToBeDeleted){
        patientsList.remove(patientToBeDeleted);
    }
    
    public Patient searchByPatientName(String FirstName){
        for(Patient patient:patientsList){
            Patient p = (Patient) patient; 
            return patient;
        }  
     return null;
    }
    
     public Patient createPatient(String name,int age,
        String prefpharm,String primdoc ){
        Patient patient = new Patient();
        patient.setPatientName(name);
        patient.setAge(age);
        patient.setPrefpharm(prefpharm);
        patient.setPridoctor(primdoc);
        patientsList.add(patient);
        return patient;
    }
}

    


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

/**
 *
 * @author anusha_m
 */
import Business.Role.DoctorRole;
import Business.Role.PatientManagementAdminRole;
import Business.Role.Role;
import java.util.ArrayList;
public class PatientManagementOrganization extends Organization {
    public PatientManagementOrganization() {
        super(Organization.Type.PatientManagement.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new PatientManagementAdminRole());
        return roles;
    }
     
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

/**
 *
 * @author anusha_m
 */
import Business.Role.AmbulanceManagerRole;
import Business.Role.DoctorRole;
import Business.Role.PatientManagementAdminRole;
import Business.Role.Role;
import java.util.ArrayList;
public class AmbulanceManagementOrganization extends Organization{

    public AmbulanceManagementOrganization() {
        super(Organization.Type.AmbulanceManagement.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new AmbulanceManagerRole());
        return roles;
    }  
}

package com.neu.esd;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.esd.pojo.User;

@Component
public class RegistrationUserValidator implements Validator{

	@Override
	 public boolean supports(Class aClass)
    {
        return aClass.equals(User.class);
    }
	@Override
	public void validate(Object obj, Errors errors) {
        User user = (User) obj;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "error.invalid.user", "First Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "error.invalid.user", "Last Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.invalid.user", "User Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.user", "Password Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "street", "error.invalid.user", "Street Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "city", "error.invalid.user", "City Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "state", "error.invalid.user", "State Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passId", "error.invalid.user", "Passport Id Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creCardNo", "error.invalid.user", "Credit card Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cvv", "error.invalid.user", "cvv Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "expDate", "error.invalid.user", "expDate Required");
       
	}

}

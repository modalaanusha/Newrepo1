package com.neu.esd;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neu.esd.pojo.BookedFlights;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;
import com.neu.esd.service.FlightService;


@Controller
public class AdminController {
	
	@Autowired
	FlightValidator validator;
	
	@Autowired
	FlightService flightSer;
	
	@RequestMapping(value="/addflights", method=RequestMethod.GET)
	public String addFliScreen(@ModelAttribute("flights") Flights flight, BindingResult result){
		return "addFlightsAdmin";
	}
	
	@RequestMapping(value="/viewupdateflights", method=RequestMethod.GET)
	public String viewUpdateFlights(@ModelAttribute("flights") Flights flight, BindingResult result){
		return "viewandUpdateFlights";
	}
	
	@RequestMapping(value="/updatenext", method=RequestMethod.GET)
	public String UpdateNextFlights(@ModelAttribute("flights") Flights flight, BindingResult result){
		
		
		return "updateNextFlight";
	}
	
	
	@RequestMapping(value="/addflights", method=RequestMethod.POST)
	public String addFlightsToDb(@ModelAttribute("flights") Flights flight, BindingResult result){
		
		validator.validate(flight, result);
		   if (result.hasErrors()) {
	            return "addFlightsAdmin";
	        }
		
		try{
    		 System.out.println("inside control" +flight.getAvaiSeats());
    		flightSer.createFlights(flight.getSrcCity(), flight.getDestCity(), 
    	    flight.getDepDate(),flight.getArrDate(), flight.getDepTime(),
    	    flight.getArrTime(),flight.getAvaiSeats(),flight.getFare());
		
    	
    	}catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
           return "addFlightSuccess";

	}
	
	@RequestMapping(value = "/viewupdateflights", method = RequestMethod.POST)
	public String ajaxsearch(@ModelAttribute("flights") Flights flight, BindingResult result
			,HttpSession session,
			HttpServletRequest req,HttpServletResponse response) {
		List fliList = new ArrayList<Flights>();
		try{
			
			List<Flights> flist=flightSer.getFlightsByCity(flight.getSrcCity(),
			flight.getDestCity());
			System.out.println("size" +flist.size());
			Iterator<Flights> fliitr= flist.iterator();  
		       while(fliitr.hasNext()){  
		    	   Flights flightto = (Flights) fliitr.next();
		           fliList.add(flightto);
				} 
		       session.setAttribute("flightLi", fliList);
	    return "updateFlights";

	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
			return null;
	}
		
	}
	
	
	@RequestMapping(value="/updatenext/{flightid}",method = RequestMethod.GET)
	public String updateScreen(@PathVariable("flightid") long fliid,
			//@ModelAttribute("flights") Flights flight,BindingResult result,
			Model model,HttpSession session) {
	
		try {
			Flights flightUpdate = flightSer.getFlightsById(fliid);
			session.setAttribute("flightToUpdate",flightUpdate);
			model.addAttribute("flightToUpdate", flightUpdate);
			return"updateSelectedFlight";
		}catch(Exception e) {
			
		}
				return null;	
	}
	
	
	
	
	@RequestMapping(value="/updateflights",method = RequestMethod.GET)
	public String updateScreen(
			@ModelAttribute("flightToUpdate") Flights flight,BindingResult result,
			Model model,HttpSession session) {
		validator.validate(flight, result);
		   if (result.hasErrors()) {
	            return "updateSelectedFlight";
	        }
		Flights flightforId = (Flights) session.getAttribute("flightToUpdate");
		try {
			flightSer.updateFlight(flightforId.getId(),flight);
			
			return"updateFlightSuccess";
		}catch(Exception e) {
			
		}
		
		return null;
	}
	
	@RequestMapping(value="/viewbookingsfl",method = RequestMethod.GET)
	public String viewBookingByFlight(@ModelAttribute("flights") Flights flight,BindingResult result,
			HttpSession session) {
				return "viewBookingsFl";	
	}
	
	@RequestMapping(value="/deletefl",method = RequestMethod.GET)
	public String deleteFlight(@ModelAttribute("flights") Flights flight,BindingResult result,
			HttpSession session) {		
				return "viewBookingsFldel";	
	}
	
	@RequestMapping(value="/deletefl",method = RequestMethod.POST)
	public String deleteFlightPost(@ModelAttribute("flights") Flights flight,BindingResult result,
			HttpSession session) {		
		List fliList = new ArrayList<Flights>();
		try{
			List<Flights> flist=flightSer.getFlightsByCity(flight.getSrcCity(),
			flight.getDestCity());
			System.out.println("size" +flist.size());
			Iterator<Flights> fliitr= flist.iterator();  
		       while(fliitr.hasNext()){  
		    	   Flights flightto = (Flights) fliitr.next();
		           fliList.add(flightto);
				} 
		       session.setAttribute("flightLiDel", fliList);
	    return "viewBookingsFldelNext";

	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
			return null;
	}
			
	}
	
	@RequestMapping(value="/viewbookingsfl",method = RequestMethod.POST)
	public String viewBookingByFlightNext(@ModelAttribute("flights") Flights flight,BindingResult result,
			HttpSession session) {
		List fliList = new ArrayList<Flights>();
		try{
			List<Flights> flist=flightSer.getFlightsByCity(flight.getSrcCity(),
			flight.getDestCity());
			System.out.println("size" +flist.size());
			Iterator<Flights> fliitr= flist.iterator();  
		       while(fliitr.hasNext()){  
		    	   Flights flightto = (Flights) fliitr.next();
		           fliList.add(flightto);
				} 
		       session.setAttribute("flightLiBook", fliList);
		       session.removeAttribute("flightLiBooked");
	    return "viewBookingsFlNext";

	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
			return null;
	}
			
	}
	
	
	@RequestMapping(value="/viewbookingsflajax/{id}",method = RequestMethod.GET)
	public String viewBookingByFlightNextAjax(@PathVariable("id") long flightId,@ModelAttribute("flights") Flights flight,BindingResult result,
			HttpSession session) {
		User user = (User) session.getAttribute("UserAcc");
		try {
			List<BookedFlights> flightList = flightSer.getBookingByFlight(flightId);
			System.out.println("flight---"+flightList.size());
			
		     // ObjectMapper mapper = new ObjectMapper();
		     session.setAttribute("flightLiBooked", flightList);
			//System.out.println("mapper==" +mapper.writeValueAsString(flightList));
				
			  //return mapper.writeValueAsString(flightList);
		return "viewBookingsFlNext";
		}catch(Exception e) {
			
		}
		return null;			
	}
	
	
	@RequestMapping(value="/viewbookingsdelajax/{id}",method = RequestMethod.GET)
	public String deleteByFlightNextAjax(@PathVariable("id") long flightId,Model model,
			HttpSession session) {
		try {
			Boolean isValid=flightSer.BookingCheck(flightId);
	       	if(!isValid) {
	       		session.setAttribute("flId", flightId);
	       		return "viewBookingsFldelFail";       	
	       	}
			flightSer.deleteFlight(flightId);
							return "viewBookingsFldelSuccess";
		}catch(Exception e) {
			
		}
		return null;			
	}

}



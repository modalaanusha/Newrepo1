package com.neu.esd;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;


@Controller
public class RegistrationController {
	
	
	
        	
}

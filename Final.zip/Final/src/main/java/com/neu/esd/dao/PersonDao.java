package com.neu.esd.dao;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;






public class PersonDao extends DAO{
	
	public User createUser(String username, String password, String firstname, String lastname)
	        throws Exception {
	    try {
	        begin();
	        System.out.println("inside DAO" +password);
	        
	        User user=new User();
	        user.setFirstName(firstname);
	        user.setLastName(lastname);
	        user.setUserName(username);
	        user.setPassword(password); 
	        user.setRole("User");
	        
	        getSession().save(user);
	        
	        commit();
	        return user;
	    } catch (HibernateException e) {
	        rollback();
	        //throw new AdException("Could not create user " + username, e);
	        throw new Exception("Exception while creating user: " + e.getMessage());
	    }
	}
	
	public Person getUserByNameAndPassword(String userName, String password)
            throws Exception {
		try {
			begin();
            Query q = getSession().createQuery("from Person where userName = :userName and password = :password");
            
            q.setString("userName", userName);
            q.setString("password", password);
            
            Person user = (Person) q.uniqueResult();
            //System.out.println("USSSS"+userAccount.getUserName());
            if(user==null){
            	System.out.println("no userrrr");
            }
            commit();
            return user;
		} catch (Exception e) {
			rollback();
            
		}
		return null;	
    }
	



public Admin createAdmin(String username, String password, String firstname, String lastname)
        throws Exception {
    try {
        begin();
      
        Admin admin=new Admin();
        admin.setFirstName(firstname);
        admin.setLastName(lastname);
        admin.setUserName(username);
        admin.setPassword(password); 
        
        admin.setRole("Admin");
        
        getSession().save(admin);
        
        commit();
        return admin;
    } catch (HibernateException e) {
        rollback();
        //throw new AdException("Could not create user " + username, e);
        throw new Exception("Exception while creating user: " + e.getMessage());
    }
}

public Boolean employeeCheck(Person person) throws Exception{
	
	
	ArrayList<Person> users = new ArrayList();
	Query q = getSession().createQuery("from Person");
	
	users = (ArrayList<Person>)q.list();
	for(Person u:users){
		System.out.println("given"+person.getUserName()+"actual"+u.getUserName());
		if(person.getUserName().equalsIgnoreCase(u.getUserName())){
			//model.addAttribute("error", "");
			
			return false;
		}
	}
	return true;

}


}




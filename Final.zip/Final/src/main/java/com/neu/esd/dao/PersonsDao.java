package com.neu.esd.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;

@Repository
@Transactional
public interface PersonsDao {
      
	public User createUser(String username, String password, String firstname, String lastname)
	        throws Exception;
	
	public Person getUserByNameAndPassword(String userName, String password)
            throws Exception;
	
	public User getUser(String userName)
            throws Exception;
	
	public Person getUserbyName(String userName)
            throws Exception;
	
	public Admin getAdmin(String userName)
            throws Exception;
	
	public Admin createAdmin(String username, String password, String firstname, String lastname)
	        throws Exception;
	
	public User updateUserProfile(int id,User user )
	        throws Exception;
	
	public Boolean userCheck(Person person) throws Exception;
	
	
}

package com.neu.esd;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.dao.PersonDao;
import com.neu.esd.pojo.User;


@Controller
public class RegistraionUserController {
	
	@Autowired
    @Qualifier("userValidator")
	RegistrationUserValidator validator;
    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
    @RequestMapping(value="/userSignup", method=RequestMethod.GET)
	public String getUserSignup(@ModelAttribute("user") User user){
		return "usersignup";
	}
	
	
	@RequestMapping(value= "/userSignup", method = RequestMethod.POST)
   public String addPerson(@ModelAttribute("user")User user,BindingResult result,Model model){
		validator.validate(user, result);
		  if (result.hasErrors()) {
	           return "usersignup";
	        }
     
   	try {
   		PersonDao personDao=new PersonDao();
   		Boolean isValid=personDao.userCheck(user);
       	if(!isValid){
       		model.addAttribute("error",true);
       		return "usersignup";       	
       	}
       	
   		personDao.createUser(user.getUserName(), user.getPassword(),
   				user.getFirstName(), user.getLastName());
   		System.out.println("inside rty");
   		
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          return "registrationSuccess";
       }
        
}
package com.neu.esd.dao;

import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;

@Repository
@Transactional
public class PersonsDaoImpl extends DAO implements PersonsDao {

	@Override
	public User createUser(String username, String password, String firstname, String lastname)
	        throws Exception {
	    try {
	        begin();
	        User user=new User();
	        user.setFirstName(firstname);
	        user.setLastName(lastname);
	        user.setUserName(username);
	        user.setPassword(password); 
	        user.setRole("User");
	        
	        getSession().save(user);
	        
	        commit();
	        return user;
	    } catch (HibernateException e) {
	        rollback();
	        //throw new AdException("Could not create user " + username, e);
	        throw new Exception("Exception while creating user: " + e.getMessage());
	    }
	}
	
	@Override
	public Person getUserByNameAndPassword(String userName, String password)
            throws Exception {
		try {
			begin();
            Query q = getSession().createQuery("from Person where userName = :userName and password = :password");
            
            q.setString("userName", userName);
            q.setString("password", password);
            
            Person user = (Person) q.uniqueResult();
           
           
            commit();
            return user;
		} catch (Exception e) {
			rollback();
            
		}
		return null;	
    }
	

	@Override
	public User getUser(String userName)
            throws Exception {
		try {
			begin();
            Query q = getSession().createQuery("from User where userName = :username");
            
            q.setString("username", userName);
            
            User user = (User) q.uniqueResult();
            
            commit();
            return user;
		} catch (Exception e) {
			rollback();
            
		}
		return null;	
    }
	
	@Override
	public Admin getAdmin(String userName)
            throws Exception {
		try {
			begin();
            Query q = getSession().createQuery("from Admin where userName = :username");
            
            q.setString("username", userName);
            
            Admin admin = (Admin) q.uniqueResult();
            
            commit();
            return admin;
		} catch (Exception e) {
			rollback();
            
		}
		return null;	
    }

	@Override
public Admin createAdmin(String username, String password, String firstname, String lastname)
        throws Exception {
    try {
        begin();
      
        Admin admin=new Admin();
        admin.setFirstName(firstname);
        admin.setLastName(lastname);
        admin.setUserName(username);
        admin.setPassword(password); 
        
        admin.setRole("Admin");
        
        getSession().save(admin);
        
        commit();
        return admin;
    } catch (HibernateException e) {
        rollback();
        //throw new AdException("Could not create user " + username, e);
        throw new Exception("Exception while creating user: " + e.getMessage());
    }
}

	@Override
public User updateUserProfile(int id,User user )
        throws Exception {
    try {
    	begin();
    	System.out.println("id--" +id);
    	Query q = getSession().createQuery("from User where personID=:pid");
		 q.setLong("pid", id);
		 User userUpdate = (User) q.uniqueResult();
		 System.out.println("id--" +userUpdate.getPersonID());
		 userUpdate.setStreet(user.getStreet());
		 userUpdate.setCity(user.getCity());
		 userUpdate.setState(user.getState());
		 userUpdate.setCreCardNo(user.getCreCardNo());
		 userUpdate.setCvv(user.getCvv());
		 userUpdate.setPassId(user.getPassId());
		 userUpdate.setExpDate(user.getExpDate());
		 getSession().update(userUpdate);
        commit();
        return userUpdate;
    } catch (HibernateException e) {
        rollback();
        //throw new AdException("Could not create user " + username, e);
        throw new Exception("Exception while creating user: " + e.getMessage());
    }
}
	@Override
public Boolean userCheck(Person person) throws Exception{
	
	
	ArrayList<Person> users = new ArrayList();
	Query q = getSession().createQuery("from Person");
	
	users = (ArrayList<Person>)q.list();
	for(Person u:users){
		System.out.println("given"+person.getUserName()+"actual"+u.getUserName());
		if(person.getUserName().equalsIgnoreCase(u.getUserName())){
			//model.addAttribute("error", "");
			
			return false;
		}
	}
	return true;

}

}

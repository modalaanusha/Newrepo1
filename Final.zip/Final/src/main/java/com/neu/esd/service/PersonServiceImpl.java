package com.neu.esd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.dao.PersonsDao;
import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;

@Service
@Transactional
public class PersonServiceImpl implements PersonService {
 
	@Autowired
	PersonsDao perDao;
	
	@Override
	@Transactional
	public User createUser(String username, String password, String firstname, String lastname) throws Exception {
		// TODO Auto-generated method stub
		return perDao.createUser(username, password, firstname, lastname);
	}

	@Override
	@Transactional
	public Person getUserByNameAndPassword(String userName, String password) throws Exception {
		// TODO Auto-generated method stub
		return perDao.getUserByNameAndPassword(userName, password);
	}

	@Override
	@Transactional
	public User getUser(String userName) throws Exception {
		// TODO Auto-generated method stub
		return perDao.getUser(userName);
	}

	@Override
	@Transactional
	public Admin getAdmin(String userName) throws Exception {
		// TODO Auto-generated method stub
		return perDao.getAdmin(userName);
	}

	@Override
	@Transactional
	public Admin createAdmin(String username, String password, String firstname, String lastname) throws Exception {
		// TODO Auto-generated method stub
		return perDao.createAdmin(username, password, firstname, lastname);
	}

	@Override
	@Transactional
	public User updateUserProfile(int id, User user) throws Exception {
		// TODO Auto-generated method stub
		return perDao.updateUserProfile(id, user);
	}

	@Override
	@Transactional
	public Boolean userCheck(Person person) throws Exception {
		// TODO Auto-generated method stub
		return perDao.userCheck(person);
	}

}

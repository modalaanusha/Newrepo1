package com.neu.esd;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.esd.pojo.User;

@Component
public class updateProfileValidator implements Validator {

	@Override
	 public boolean supports(Class aClass)
   {
       return aClass.equals(User.class);
   }
	@Override
	public void validate(Object obj, Errors errors) {
       User user = (User) obj;
       
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "street", "error.invalid.user", "Street Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "city", "error.invalid.user", "City Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "state", "error.invalid.user", "State Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passId", "error.invalid.user", "Passport Id Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creCardNo", "error.invalid.user", "Credit card Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cvv", "error.invalid.user", "cvv Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "expDate", "error.invalid.user", "expDate Required");
      
	}

}

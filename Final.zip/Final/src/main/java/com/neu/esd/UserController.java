package com.neu.esd;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;
import com.neu.esd.service.FlightService;
import com.neu.esd.service.PersonService;


@Controller
public class UserController {

	@Autowired
	PersonService perSer;
	
	@Autowired
	FlightService fliSer;
	
	@Autowired
	@Qualifier("updateValidator")
	updateProfileValidator validator;
	@RequestMapping(value="/buildprofile", method=RequestMethod.GET)
	public String buildProfile(
			HttpSession session,Model model){
		try {
			User userProf = (User) session.getAttribute("UserAcc");
			User userUp = (User) perSer.getUser(userProf.getUserName());
			model.addAttribute("user", userUp);
			return "userBuildProfile";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	@RequestMapping(value="/buildprofile", method=RequestMethod.POST)
	public String buildProfileStart(@ModelAttribute("user")User user,BindingResult result,
		HttpSession session){
		validator.validate(user, result);
		  if (result.hasErrors()) {
	           return "userBuildProfile";
	        }
    		try {
    			System.out.println("tyu------user");
    		    User userSesn = (User)session.getAttribute("UserAcc");
    		    
    	         perSer.updateUserProfile(userSesn.getPersonID(),user);
    	         return "userProfileUpdateSuccess";
    		        } catch (Exception e) {
    		            e.printStackTrace();
    		        }
			return null;
    			
	}
	
	
	@RequestMapping(value="/bookflights", method=RequestMethod.GET)
	public String bookFlights(@ModelAttribute("flight")Flights flights,BindingResult result){
		return "viewAndBookFlights";
	}
	
	
	
	@RequestMapping(value="/bookflights", method=RequestMethod.POST)
	public String bookFlightsNext(@ModelAttribute("flight")Flights flights,BindingResult result,
			HttpSession session){
		
		List fliList = new ArrayList<Flights>();
		List fliListRet = new ArrayList<Flights>();
		session.setAttribute("arrDateRet", flights.getArrDate());
		System.out.println("flights arr date----" +flights.getArrDate());
		try{
			if(session.getAttribute("arrDateRet") == null || session.getAttribute("arrDateRet").equals("")) {
				List<Flights> flist=fliSer.getFlightsBySearch(flights.getSrcCity(),
						flights.getDestCity(),flights.getDepDate());
						System.out.println("size" +flist.size());
						Iterator<Flights> fliitr= flist.iterator();  
					       while(fliitr.hasNext()){  
					    	   Flights flightto = (Flights) fliitr.next();
					           fliList.add(flightto);
							} 
					session.setAttribute("flightLiDep", fliList);
				    return "bookFlights";
				
			}else {

				List<Flights> flist=fliSer.getFlightsBySearch(flights.getSrcCity(),
							flights.getDestCity(),flights.getDepDate());
							System.out.println("size" +flist.size());
							Iterator<Flights> fliitr= flist.iterator();  
						       while(fliitr.hasNext()){  
						    	   Flights flightto = (Flights) fliitr.next();
						           fliList.add(flightto);
								} 
						List<Flights> flistRet=fliSer.getFlightsBySearch(flights.getDestCity(),
								flights.getSrcCity(),flights.getArrDate());
								System.out.println("size" +flistRet.size());
								Iterator<Flights> fliitrRet= flistRet.iterator();  
							       while(fliitrRet.hasNext()){  
							    	   Flights flighttoRet = (Flights) fliitrRet.next();
							           fliListRet.add(flighttoRet);
									} 
							session.setAttribute("flightLiDep", fliList);
							session.setAttribute("flightLiArr", fliListRet);
					    return "bookFlights";	
			}
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
			return null;
	}
	}
	
	
	
	@RequestMapping(value="/booknext/{flightid}",method = RequestMethod.GET)
	public String updateUserDetails(@PathVariable("flightid") long fliid,
			//@ModelAttribute("flights") Flights flight,BindingResult result,
			Model model,HttpSession session) {
		
		System.out.println("arr date---" +session.getAttribute("arrDateRet") );
		try {
			if(session.getAttribute("arrDateRet") == null || session.getAttribute("arrDateRet").equals("")) {
				Flights flightUpdate = fliSer.getFlightsById(fliid);
				session.setAttribute("flightToUpdate",flightUpdate);
				User user = (User) session.getAttribute("UserAcc");
				User userBooking = fliSer.getUserById(user.getPersonID());
				model.addAttribute("userbooking", userBooking);
				return"bookSelectedFlight";
			
			}else {
			
				Flights flightUpdate = fliSer.getFlightsById(fliid);
				session.setAttribute("flightToUpdate",flightUpdate);
				return "bookRetFlight";
			}
		}catch(Exception e) {
			
		}
				return null;	
	}
	
	@RequestMapping(value="/booknextret/{flightid}",method = RequestMethod.GET)
	public String bookRetFlight(@PathVariable("flightid") long fliid,
			//@ModelAttribute("flights") Flights flight,BindingResult result,
			Model model,HttpSession session) {
		
		try {
			Flights flightUpdate = fliSer.getFlightsById(fliid);
			session.setAttribute("flightToUpdateRet",flightUpdate);
			User user = (User) session.getAttribute("UserAcc");
			User userBooking = fliSer.getUserById(user.getPersonID());
			model.addAttribute("userbooking", userBooking);
			return"bookSelectedFlight";	
		}catch(Exception e) {
			
		}
				return null;	
	}
	
	@RequestMapping(value="/bookflightsselect",method = RequestMethod.POST)
	public String bookReservation(@ModelAttribute("userbooking") User user,
			//@ModelAttribute("flights") Flights flight,BindingResult result,
			BindingResult result,HttpSession session) {
		validator.validate(user, result);
		  if (result.hasErrors()) {
	           return "userBuildProfile";
	        }
		try {
			
			if(session.getAttribute("arrDateRet") == null || session.getAttribute("arrDateRet").equals("")) {
				Flights flight = (Flights) session.getAttribute("flightToUpdate");
				User userSes = (User) session.getAttribute("UserAcc");
				System.out.println("userid0--" +userSes.getPersonID());
				User userUpd = perSer.updateUserProfile(userSes.getPersonID(), user);
				fliSer.updateFlightBook(flight.getId());
				fliSer.bookFlights(userUpd,flight.getId());
				return"bookFlightSuccess";
			}else {
				Flights flight = (Flights) session.getAttribute("flightToUpdate");
				Flights flightRet = (Flights) session.getAttribute("flightToUpdateRet");
				User userSes = (User) session.getAttribute("UserAcc");
				
				User userUpd = perSer.updateUserProfile(userSes.getPersonID(), user);
				fliSer.updateFlightBook(flight.getId());
				fliSer.updateFlightBook(flight.getId());
				fliSer.bookFlightsRound(userUpd,flight.getId(),flightRet.getId());
				return"bookFlightSuccess";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
				return "bookFlightsFail";	
	}
	
}

package com.neu.esd.pojo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;



@Entity
@Table
public class BookedFlights {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="bookedFlightsID",unique=true,nullable=false)
    private long id;
	
	@ManyToMany
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	private Set<Flights> flight=new HashSet<Flights>();
	
	@ManyToOne
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	@JoinColumn(name="personID")
	private User user;
	
	
	@Column(name="date")
	private Date date;
	
	@Column(name="type")
	private String type;

	
	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public Set<Flights> getFlight() {
		return flight;
	}


	public void setFlight(Set<Flights> flight) {
		this.flight = flight;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}
	
	
	

}

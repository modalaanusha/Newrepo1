package com.neu.esd.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;
import com.neu.esd.service.PersonService;
@Service
public class UserDetailServiceImpl implements UserDetailsService {

	@Autowired
	private PersonService perSer;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Person person = new Person();
		try {
			person = perSer.getUserbyName(userName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UsernameNotFoundException("Invalid user name");
		}
		
		if(person != null) {
			List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			authorities.add(new SimpleGrantedAuthority(person.getRole()));
			return new org.springframework.security.core.userdetails.User(person.getUserName(),person.getPassword(),authorities);
		}
		
		throw new UsernameNotFoundException("Invalid user name");
		
	}

}

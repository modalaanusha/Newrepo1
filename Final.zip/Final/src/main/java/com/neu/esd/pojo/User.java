package com.neu.esd.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity
@Table
@PrimaryKeyJoinColumn(name="personID")
public class User extends Person{

	public User() {
	}
	
	@OneToMany(mappedBy="user")
	private Set<BookedFlights> ja=new HashSet<BookedFlights>();
	
	@Column(name="street")
	private String street;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	
	@Column(name="passId")
	private String passId;
	
	@Column(name="creCardNo")
	private String creCardNo;
	
	@Column(name="cvv")
	private String cvv;
	
	@Column(name="expDate")
	private String expDate;
	
	
	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPassId() {
		return passId;
	}

	public void setPassId(String passId) {
		this.passId = passId;
	}

	public String getCreCardNo() {
		return creCardNo;
	}

	public void setCreCardNo(String creCardNo) {
		this.creCardNo = creCardNo;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public Set<BookedFlights> getJa() {
		return ja;
	}

	public void setJa(Set<BookedFlights> ja) {
		this.ja = ja;
	}

	
	
	
}

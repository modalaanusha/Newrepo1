package com.neu.esd;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.User;

@Component
public class RegistrationAdminValidator implements Validator {
	@Override
	 public boolean supports(Class aClass)
   {
       return aClass.equals(Admin.class);
   }
	@Override
	public void validate(Object obj, Errors errors) {

       Admin admin = (Admin) obj;
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "error.invalid.admin", "First Name Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "error.invalid.admin", "Last Name Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.invalid.admin", "User Name Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.admin", "Password Required");
       
	}

}

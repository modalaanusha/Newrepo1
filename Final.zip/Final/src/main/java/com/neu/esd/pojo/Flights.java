package com.neu.esd.pojo;

import java.sql.Time;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name="Flights")
public class Flights {
	
	public Flights(){}
	
	@ManyToMany(mappedBy="flight")
	@Cascade(CascadeType.DELETE)
	private Set<BookedFlights> flights=new HashSet<BookedFlights>();
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="flightId",unique=true,nullable=false)
    private long id;
	
	@Column(name="srcCity")
	private String srcCity;
	
	@Column(name="destCity")
	private String destCity;
	
	@Column(name="depDate")
	private String depDate;
	
	@Column(name="arrDate")
	private String arrDate;
	

	@Column(name="arrTime")
	private String arrTime;
	

	@Column(name="depTime")
	private String depTime;
	
	@Column(name="avaiSeats")
	private int avaiSeats;
	
	@Column(name="fare")
	private int fare;

	public String getSrcCity() {
		return srcCity;
	}

	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}

	public String getDestCity() {
		return destCity;
	}

	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}

	public int getAvaiSeats() {
		return avaiSeats;
	}

	public void setAvaiSeats(int avaiSeats) {
		this.avaiSeats = avaiSeats;
	}

	public String getDepDate() {
		return depDate;
	}

	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}

	public String getArrDate() {
		return arrDate;
	}

	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}

	public String getArrTime() {
		return arrTime;
	}

	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	public String getDepTime() {
		return depTime;
	}

	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Set<BookedFlights> getFlights() {
		return flights;
	}

	public void setFlights(Set<BookedFlights> flights) {
		this.flights = flights;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	
}

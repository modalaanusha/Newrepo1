package com.neu.esd.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Flights")
public class Flights {
	
	public Flights(){}
	@Column(name="srcCity")
	private String srcCity;
	
	@Column(name="destCity")
	private String destCity;
	
	@Column(name="depDate")
	private Date depDate;
	
	@Column(name="arrDate")
	private Date arrDate;
	
	@Column(name="avaiSeats")
	private int avaiSeats;

	public String getSrcCity() {
		return srcCity;
	}

	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}

	public String getDestCity() {
		return destCity;
	}

	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}

	public Date getDepDate() {
		return depDate;
	}

	public void setDepDate(Date depDate) {
		this.depDate = depDate;
	}

	public Date getArrDate() {
		return arrDate;
	}

	public void setArrDate(Date arrDate) {
		this.arrDate = arrDate;
	}

	public int getAvaiSeats() {
		return avaiSeats;
	}

	public void setAvaiSeats(int avaiSeats) {
		this.avaiSeats = avaiSeats;
	}

	
	
	
}

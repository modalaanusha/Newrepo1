package com.neu.esd;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.neu.esd.dao.FlightsDao;
import com.neu.esd.dao.PersonDao;
import com.neu.esd.pojo.BookedFlights;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;


@Controller
public class FlightsController {
@Autowired
FlightsDao flightDao;
@Autowired
PersonDao perDao;
	@RequestMapping(value="/flights.htm", method=RequestMethod.GET)
	public String getFliScreen(@ModelAttribute("flights") Flights flight, BindingResult result){
		return "home";
	}
	
	@RequestMapping(value="/searchFlights.htm",method = RequestMethod.GET)
	public String doSubmitAction(@ModelAttribute("flights") Flights flight, BindingResult result,HttpSession session
			,HttpServletRequest request,Model model) throws Exception {
		model.addAttribute("flights", new Flights());
		return "login";
	}
	
	
	@RequestMapping(value="/viewbookings", method=RequestMethod.GET)
	public String viewBookings(HttpSession session){
		User user = (User) session.getAttribute("UserAcc");
		try {
			List<BookedFlights> bfl = flightDao.getBookingsByUser(user);
			session.setAttribute("bookedFl", bfl);
			User userSes = (User) perDao.getUser(user.getUserName());
			session.setAttribute("userAcc", userSes);
		}catch(Exception e) {
			
		}
		return "viewBookings";
	}
	
	@RequestMapping(value="/viewbookings/{id}", method=RequestMethod.POST)
	public @ResponseBody String viewBookingsFlightDetails(@PathVariable("id") long bookingId,
			HttpSession session){
		User user = (User) session.getAttribute("UserAcc");
		try {
			List<Flights> flightList = flightDao.getFlightsByBooking(bookingId);
			
		       ObjectMapper mapper = new ObjectMapper();
		     
				System.out.println(mapper.writeValueAsString(flightList));
				
			    return mapper.writeValueAsString(flightList);
		}catch(Exception e) {
			
		}
		return "viewBookings";
	}
	
	
}

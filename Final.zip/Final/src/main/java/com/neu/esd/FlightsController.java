package com.neu.esd;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.pojo.Flights;

@Controller
public class FlightsController {

	@RequestMapping(value="/flights.htm", method=RequestMethod.GET)
	public String getFliScreen(@ModelAttribute("flights") Flights flight, BindingResult result){
		return "home";
	}
	
	@RequestMapping(value="/searchFlights.htm",method = RequestMethod.GET)
	public String doSubmitAction(@ModelAttribute("flights") Flights flight, BindingResult result,HttpSession session
			,HttpServletRequest request,Model model) throws Exception {
		model.addAttribute("flights", new Flights());
		return "login";
	}
}

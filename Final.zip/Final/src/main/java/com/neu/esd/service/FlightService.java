package com.neu.esd.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.pojo.BookedFlights;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;

@Service
@Transactional
public interface FlightService {
	public Flights createFlights(String srcCity, String destcity, String depDate, String arrDate,
			String depTime,String arrTime,int avaiSeats,int fare)
	        throws Exception ;
	public List<Flights> searchFlights(String srcCity, String destCity, Date depDate, Date arrDate)
	        throws Exception;
	
	public List<Flights> getFlightsByCity(String srcCity,String depCity)
	        throws Exception;
	
	public Flights getFlightsById(long Id)
	        throws Exception;
	
	public List<Flights> getFlightsBySearch(String srcCity,String depCity,String depDate)
	        throws Exception;
	
	public Flights updateFlight(long Id,Flights flight);
	
	public Flights updateFlightBook(long Id);
	
	public User getUserById(int personID);
	
	public BookedFlights bookFlights(User user, long Id);
	
	public BookedFlights bookFlightsRound(User user, long id, long id2) ;
	
	public List<BookedFlights> getBookingsByUser(User user);
	
	public List<Flights> getFlightsByBooking(long bookingId);
	
	public List<BookedFlights> getBookingByFlight(long flightId);
	void deleteFlight(long flightId);
	
	public Boolean BookingCheck(long id) throws Exception;
	
	public void cancelBooking(long Id);
}

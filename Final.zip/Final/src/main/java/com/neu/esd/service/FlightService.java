package com.neu.esd.service;

import java.util.Collection;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.pojo.Flights;

@Service
@Transactional
public interface FlightService {
	void add(Flights flight) throws Exception;
	void delete(Flights flight) throws Exception;
	public Collection<Flights> getFlights() throws Exception;

}

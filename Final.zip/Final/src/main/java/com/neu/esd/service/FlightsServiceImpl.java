package com.neu.esd.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.dao.FlightsDao;
import com.neu.esd.pojo.Flights;


@Service
@Transactional
public class FlightsServiceImpl implements FlightService {

	@Autowired
	FlightsDao flightDao;
	
	@Override
	public void add(Flights flight) throws Exception {
		// TODO Auto-generated method stub
      
	}

	@Override
	public void delete(Flights flight) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public Collection<Flights> getFlights() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}


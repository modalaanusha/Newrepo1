package com.neu.esd.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.dao.FlightDao;

import com.neu.esd.pojo.BookedFlights;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;


@Service
@Transactional
public class FlightsServiceImpl implements FlightService {

	@Autowired
	FlightDao flightDao;

	@Override
	@Transactional
	public Flights createFlights(String srcCity, String destcity, String depDate, String arrDate, String depTime,
			String arrTime, int avaiSeats, int fare) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.createFlights(srcCity, destcity, depDate, arrDate, depTime, arrTime, avaiSeats, fare);
	}

	@Override
	@Transactional
	public List<Flights> searchFlights(String srcCity, String destCity, Date depDate, Date arrDate) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.searchFlights(srcCity, destCity, depDate, arrDate);
	}

	@Override
	@Transactional
	public List<Flights> getFlightsByCity(String srcCity, String depCity) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.getFlightsByCity(srcCity, depCity);
	}

	@Override
	@Transactional
	public Flights getFlightsById(long Id) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.getFlightsById(Id);
	}

	@Override
	@Transactional
	public List<Flights> getFlightsBySearch(String srcCity, String depCity, String depDate) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.getFlightsBySearch(srcCity, depCity, depDate);
	}

	@Override
	@Transactional
	public Flights updateFlight(long Id, Flights flight) {
		// TODO Auto-generated method stub
		return flightDao.updateFlight(Id, flight);
	}

	@Override
	@Transactional
	public Flights updateFlightBook(long Id) {
		// TODO Auto-generated method stub
		return flightDao.updateFlightBook(Id);
	}

	@Override
	@Transactional
	public User getUserById(int personID) {
		// TODO Auto-generated method stub
		return flightDao.getUserById(personID);
	}

	@Override
	@Transactional
	public BookedFlights bookFlights(User user, long Id) {
		// TODO Auto-generated method stub
		return flightDao.bookFlights(user, Id);
	}

	@Override
	@Transactional
	public BookedFlights bookFlightsRound(User user, long id, long id2) {
		// TODO Auto-generated method stub
		return flightDao.bookFlightsRound(user, id, id2);
	}

	@Override
	@Transactional
	public List<BookedFlights> getBookingsByUser(User user) {
		// TODO Auto-generated method stub
		return flightDao.getBookingsByUser(user);
	}

	@Override
	@Transactional
	public List<Flights> getFlightsByBooking(long bookingId) {
		// TODO Auto-generated method stub
		return flightDao.getFlightsByBooking(bookingId);
	}

	@Override
	@Transactional
	public List<BookedFlights> getBookingByFlight(long flightId) {
		// TODO Auto-generated method stub
		return flightDao.getBookingByFlight(flightId);
	}

	@Override
	@Transactional
	public void deleteFlight(long flightId) {
		// TODO Auto-generated method stub
		flightDao.deleteFlight(flightId);
	}
	
	
	@Override
	@Transactional
	public void cancelBooking(long Id) {
		// TODO Auto-generated method stub
		flightDao.cancelBooking(Id);
	}

	@Override
	public Boolean BookingCheck(long id) throws Exception {
		// TODO Auto-generated method stub
		return flightDao.BookingCheck(id);
	}
	
	

}


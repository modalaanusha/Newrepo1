package com.neu.esd;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.Person;

@Component
public class FlightValidator implements Validator {

	@Override
	 public boolean supports(Class aClass)
   {
       return aClass.equals(Flights.class);
   }
	@Override
	public void validate(Object obj, Errors errors) {

       Flights fl = (Flights) obj;
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "srcCity", "error.invalid.fl", "SourceCity Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "destCity", "error.invalid.fl", "DestinationCity Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "depDate", "error.invalid.fl", "Departure date Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "arrDate", "error.invalid.fl", "Arrival date Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "depTime", "error.invalid.fl", "Departure Time Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "arrTime", "error.invalid.fl", "Arrival Time Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "avaiSeats", "error.invalid.fl", "Seats Required");
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fare", "error.invalid.fl", "Fare Required");
     
	}

}

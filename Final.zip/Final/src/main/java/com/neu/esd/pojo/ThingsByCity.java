package com.neu.esd.pojo;

import java.util.ArrayList;

public class ThingsByCity {
	
	private String name;
	private String address;
	private String rating;
	private ArrayList<String> type;
	private String open_now;
	private String icon;
	private String photos;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	public ArrayList<String> getType() {
		return type;
	}
	public void setType(ArrayList<String> type) {
		this.type = type;
	}
	public String getOpen_now() {
		return open_now;
	}
	public void setOpen_now(String open_now) {
		this.open_now = open_now;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getPhotos() {
		return photos;
	}
	public void setPhotos(String photos) {
		this.photos = photos;
	}

	
	

}

package com.neu.esd;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;


import com.neu.esd.pojo.Admin;

import com.neu.esd.pojo.Flights;

import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.ThingsByCity;
import com.neu.esd.service.FlightService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	FlightService fliSer;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "home";
	}
	
	@RequestMapping(value = "/ajaxsearchBook", method = RequestMethod.POST)
	public @ResponseBody String ajaxsearch(HttpSession session,
			HttpServletRequest req,HttpServletResponse response) {
		
		System.out.println("inside ajax");
		List fliList = new ArrayList<Flights>();
				try{
			String data = req.getParameter("datamain");
			String[] dataparts = data.split(",");
			System.out.println("inside ajax" +dataparts.length);
			System.out.println("inside ajax" +dataparts[0]);
			System.out.println("inside ajax" +dataparts[1]);
			System.out.println("inside ajax" +dataparts[2]);
			
			List<Flights> flist=fliSer.getFlightsBySearch(dataparts[0],
			dataparts[1],dataparts[2]);
			System.out.println("size" +flist.size());
			Iterator<Flights> fliitr= flist.iterator();  
		       while(fliitr.hasNext()){  
		    	   Flights flight = (Flights) fliitr.next();
		    	   flight.setFlights(null);
		           fliList.add(flight);
				} 
			if (dataparts.length == 4) {
			List<Flights> flistRet=fliSer.getFlightsBySearch(dataparts[1],
			dataparts[0],dataparts[3]);
			 System.out.println("size" +flistRet.size());
				Iterator<Flights> fliitrRet= flistRet.iterator();  
			       while(fliitrRet.hasNext()){  
			    	   Flights flightRet = (Flights) fliitrRet.next();
			    	   flightRet.setFlights(null);
			           fliList.add(flightRet);
					} 
			}
			
		      
		       System.out.println("size" +fliList.size());
		      
		       ObjectMapper mapper = new ObjectMapper();
		       System.out.println("size----" +fliList.size());
				System.out.println(mapper.writeValueAsString(fliList));
				System.out.println("size----" +fliList.size());
			    return mapper.writeValueAsString(fliList);
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
			return null;
	}
	}
	
	@RequestMapping(value = "/thingstodo.htm", method = RequestMethod.GET)
	public String thingsToDO() {
		return "thingsToDo";
	}
	
	
	@RequestMapping(value = "/thingstodo.htm", method = RequestMethod.POST)
	public String thingsSearch(HttpServletRequest req,HttpSession session) {
		try{
			String city = req.getParameter("city");
			System.out.println(city);
			String url="https://maps.googleapis.com/maps/api/place/textsearch/json?query=thingstodoin"+city+"&key=AIzaSyBEuxMPHqN8AXnSYmtlI6MOQgztmJyXJpA";
	
			
			   HttpGet get=new HttpGet(url);
			
			    	            HttpClient client1 = HttpClients.createDefault();
			    	            ResponseHandler<String> responseHandler=new BasicResponseHandler();
			    	            String responseBody = client1.execute(get, responseHandler);
			    	            try {
									JSONObject resp=new JSONObject(responseBody);
									System.out.println(resp);
									
									JSONArray resultArr =  (JSONArray)resp.get("results");
									ArrayList<ThingsByCity> thingsList = new ArrayList<ThingsByCity>();
							    	
									for(int i =0; i < resultArr.length(); i++)
									  {
									    JSONObject Jobject = resultArr.getJSONObject(i);
									    String address = Jobject.getString("formatted_address");
									    String name = Jobject.getString("name");
									    System.out.println(address);
									    String rating = null;
									    System.out.println("name--" +name);
									    try {
									    rating = Jobject.getString("rating");
									    }catch(JSONException e) {
									    	e.printStackTrace();
									    }
									    
									    Boolean open_now = false;
									    try {
										    JSONObject job = Jobject.getJSONObject("opening_hours");
										    open_now = job.getBoolean("open_now");
										    }catch(JSONException e) {
										    	e.printStackTrace();
										    }
									   
									    String icon = Jobject.getString("icon");
									JSONArray typesArrJson = (JSONArray) Jobject.get("types");
									ArrayList<String> typesArr = new ArrayList<String>();
									  for(int i1 =0; i1 < typesArrJson.length(); i1++) {
									  	String type = typesArrJson.getString(i1);
									  typesArr.add(type);
									  }
									    ThingsByCity things = new ThingsByCity();
									     things.setAddress(address);
									     things.setIcon(icon);
									     things.setName(name);
						                 things.setRating(rating);
						                things.setType(typesArr);
						                if(open_now == false) {
						                	things.setOpen_now("Closed Now");
						                }else {
						                	things.setOpen_now("Open Now");
						                }
									     thingsList.add(things);   
									  }
									session.setAttribute("thingslist", thingsList);
								} catch (JSONException e) {
									e.printStackTrace();	
								}			
		
		}catch(Exception e){
				System.out.println("Exception: " + e.getMessage());
			}
		return "thingstodoNext";
	}
	
	
}

package com.neu.esd;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;
import com.neu.esd.service.PersonService;





@Controller
public class LoginController {
	
	@Autowired
	PersonService perSer;
	
	@Autowired
	SignInValidator validator;
	
    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
	@RequestMapping(value="/login.htm", method=RequestMethod.GET)
	public String getLogin(@ModelAttribute("person") Person person, BindingResult result){
		return "login";
	}
	
	
	
	
	@RequestMapping(value="/login.htm",method = RequestMethod.POST)
	public String doSubmitSignIn(@ModelAttribute("person") Person person, BindingResult result,HttpSession session
			,HttpServletRequest request,Model model) throws Exception {
		validator.validate(person, result);
		   if (result.hasErrors()) {
	            return "login";
	        }
		   
		
		try{
			
			Person p=perSer.getUserByNameAndPassword(person.getUserName(), person.getPassword());
	       	if(p == null){
	       		model.addAttribute("error",true);
	       		return "login";       	
	       	}
	       	
			Person personAcc=perSer.getUserByNameAndPassword(person.getUserName(),person.getPassword());
			Admin admAccount=perSer.getAdmin(person.getUserName());
			System.out.println("Role--" +personAcc.getRole());
			session = request.getSession();
			if(personAcc.getRole().equalsIgnoreCase("User")){
				User userAccount=perSer.getUser(person.getUserName());
			    session.setAttribute("UserAcc",userAccount);
				return"userHome";
				
			}
			if(personAcc.getRole().equalsIgnoreCase("Admin")){
				
			    session.setAttribute("admAccount", admAccount);
				return"adminhome";
				
			}		
		}
		
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    	//	return "loginError";
	}
		model.addAttribute("error",true);
		
		return"login";
	}
	
	
	
		
	}
	
	
	




package com.neu.esd;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.Person;




@Controller
public class LoginController {
	@RequestMapping(value="/login.htm", method=RequestMethod.GET)
	public String getLogin(@ModelAttribute("person") Person person, BindingResult result){
		return "login";
	}
	
	
	
	@RequestMapping(value="/personlogin.htm",method = RequestMethod.POST)
	public String doSubmitSignIn(@ModelAttribute("person") Person person, BindingResult result,HttpSession session
			,HttpServletRequest request,Model model) throws Exception {
		
		return "login";
	}
	
	
	
}



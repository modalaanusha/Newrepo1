package com.neu.esd.dao;

import org.hibernate.HibernateException;

import com.neu.esd.pojo.BookedFlights;
import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

public class FlightsDao extends DAO {

	public Flights createFlights(String srcCity, String destcity, String depDate, String arrDate,
			String depTime,String arrTime,int avaiSeats,int fare)
	        throws Exception {
	    try {
	        begin();
	       
	        Flights flights=new Flights();
	        flights.setSrcCity(srcCity);
	        flights.setDestCity(destcity);
	        flights.setDepDate(depDate);
	        flights.setArrDate(arrDate);
	        flights.setDepTime(depTime);
	        flights.setArrTime(arrTime);
	        flights.setAvaiSeats(avaiSeats);
	        flights.setFare(fare);
	        getSession().save(flights);
	        commit();
	        return flights;
	    } catch (HibernateException e) {
	        rollback();
	        //throw new AdException("Could not create user " + username, e);
	        throw new Exception("Exception while creating user: " + e.getMessage());
	    }
	}
	
	public List<Flights> searchFlights(String srcCity, String destCity, Date depDate, Date arrDate)
	        throws Exception {
		List<Flights> flights=new ArrayList<Flights>();
		try{begin();
		Query q=getSession().createQuery("from Flights where srcCity=:srccity and"
				+ "destCity=:destcity and depDate=:depdate and arrDate=:arrdate");
		q.setString("srccity", srcCity);
        q.setString("destcity", destCity);
        q.setDate("depdate", depDate);
        q.setDate("arrdate", arrDate);
		flights=q.list();
		commit();
		}
		catch(HibernateException e){
			e.printStackTrace();
			rollback();
		}
		return flights;
	}
	
	public List<Flights> getFlightsByCity(String srcCity,String depCity)
	        throws Exception {
		List<Flights> flights=new ArrayList<Flights>();
		try{begin();
		Query q=getSession().createQuery("from Flights where srcCity=:srccity AND"
				+ " destCity=:depcity");
		q.setString("srccity", srcCity);
        q.setString("depcity", depCity);
		flights=q.list();
		commit();
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return flights;
	}
	
	public Flights getFlightsById(long Id)
	        throws Exception {
		
		try{
		begin();
		Query q=getSession().createQuery("from Flights where id=:id");
		q.setLong("id", Id);
		Flights flight = (Flights) q.uniqueResult();
		commit();
		return flight;
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return null;
		
	}
	
	public List<Flights> getFlightsBySearch(String srcCity,String depCity,String depDate)
	        throws Exception {
		List<Flights> flights=new ArrayList<Flights>();
		try{begin();
		Query q=getSession().createQuery("from Flights where srcCity=:srccity AND"
				+ " destCity=:depcity AND depDate=:depdate");
		q.setString("srccity", srcCity);
        q.setString("depcity", depCity);
        q.setString("depdate", depDate);
		flights=q.list();
		commit();
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return flights;
	}

	public Flights updateFlight(long Id,Flights flight) {
		// TODO Auto-generated method stub
		try{begin();
		Query q=getSession().createQuery("from Flights where id=:id");
		System.out.println("id---" +Id);
		System.out.println("id---" +flight.getAvaiSeats());
		q.setLong("id", Id);
		Flights flightup = (Flights) q.uniqueResult();
		flightup.setSrcCity(flight.getSrcCity());
		flightup.setDestCity(flight.getDestCity());
		flightup.setDepTime(flight.getDepTime());
		flightup.setArrTime(flight.getArrTime());
		flightup.setDepDate(flight.getDepDate());
		flightup.setArrDate(flight.getArrDate());
		flightup.setAvaiSeats(flight.getAvaiSeats());
		flightup.setFare(flight.getFare());
		 getSession().update(flightup);
		commit();
		return flightup;
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		
		return null;
	}
	
	public Flights updateFlightBook(long Id) {
		// TODO Auto-generated method stub
		try{begin();
		Query q=getSession().createQuery("from Flights where id=:id");
		
		q.setLong("id", Id);
		Flights flightup = (Flights) q.uniqueResult();
		flightup.setAvaiSeats(flightup.getAvaiSeats()-1);
		 getSession().update(flightup);
		commit();
		return flightup;
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		
		return null;
	}

	public User getUserById(int personID) {
		// TODO Auto-generated method stub

		try{begin();
		Query q=getSession().createQuery("from User where id=:id");

		q.setLong("id", personID);
		User user = (User) q.uniqueResult();
		return user;
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		
		return null;
	}

	

	public BookedFlights bookFlights(User user, long Id) {
		
				BookedFlights bookFl=new BookedFlights();
				Set<Flights> flights = new HashSet<Flights>();
				try{
					begin();
					
					Query query=getSession().createQuery("from Flights where id=:id");
					query.setLong("id",Id);
					
					Flights flight=(Flights) query.uniqueResult();
					
					bookFl.setDate(new Date());
					System.out.println("userid----" +user.getPersonID());
					bookFl.setUser(user);
					System.out.println("userid----" +user.getPersonID());
					bookFl.setType("One-way");
					flights.add(flight);
					
					bookFl.setFlight(flights);
				
					getSession().save(bookFl);
					commit();
					
					
				}
				catch(Exception e){
					e.printStackTrace();
					rollback();
					
					
					
				}
				return bookFl;
				
	}

	public List<Flights> getFlightsBySearchRound(String srcCity, String destCity, String depDate, String arrDate) {
		// TODO Auto-generated method stub
		return null;
	}

	public BookedFlights bookFlightsRound(User user, long id, long id2) {
		// TODO Auto-generated method stub
		BookedFlights bookFl=new BookedFlights();
		Set<Flights> flights = new HashSet<Flights>();
		try{
			begin();
			
			Query query=getSession().createQuery("from Flights where id=:id");
			query.setLong("id",id);
			
			Flights flight=(Flights) query.uniqueResult();
			
			bookFl.setDate(new Date());
			bookFl.setUser(user);
			bookFl.setType("Round-trip");
			flights.add(flight);
			Query query1=getSession().createQuery("from Flights where id=:id1");
			query1.setLong("id1",id2);
			Flights flight1=(Flights) query1.uniqueResult();
			flights.add(flight1);
			bookFl.setFlight(flights);
		
			getSession().save(bookFl);
			commit();
			
			
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return bookFl;
	}

	public List<BookedFlights> getBookingsByUser(User user) {
		// TODO Auto-generated method stub
		
		List<BookedFlights> bookFl=new ArrayList<BookedFlights>();
		try{
			begin();
			
			Query query=getSession().createQuery("from BookedFlights where personId=:id");
			query.setLong("id",user.getPersonID());
			
			
			bookFl=query.list();
			return bookFl;
	    
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return bookFl;
		
		
		
	}

	public List<Flights> getFlightsByBooking(long bookingId) {
		// TODO Auto-generated method stub
		Set<Flights> flSet=new HashSet<Flights>();
		List<Flights> flList = new ArrayList<Flights>();
		try{
			begin();
			
			Query query=getSession().createQuery("from BookedFlights where id=:id");
			query.setLong("id",bookingId);
			
			BookedFlights bookedFl = (BookedFlights) query.uniqueResult();
			flSet = bookedFl.getFlight();
			
			Iterator<Flights> fliitr= flSet.iterator();  
		       while(fliitr.hasNext()){  
		    	   Flights flightto = (Flights) fliitr.next();
		    	   flightto.setFlights(null);
		           flList.add(flightto);
				} 
		       System.out.println("size---" +flList.size());
			return flList;
	    
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return flList;
	
	}
	
	public List<BookedFlights> getBookingByFlight(long flightId) {
		// TODO Auto-generated method stub
		Set<BookedFlights> flSet=new HashSet<BookedFlights>();
		List<BookedFlights> flList = new ArrayList<BookedFlights>();
		try{
			begin();
			
			Query query=getSession().createQuery("from Flights where id=:id");
			query.setLong("id",flightId);
			
			Flights Fl = (Flights) query.uniqueResult();
			flSet = Fl.getFlights();
			
			Iterator<BookedFlights> fliitr= flSet.iterator();  
		       while(fliitr.hasNext()){  
		    	   BookedFlights flightto = (BookedFlights) fliitr.next();
		           flList.add(flightto);
				} 
		       System.out.println("size---" +flList.size());
			return flList;
	    
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return flList;
	
	}

	public void deleteFlight(long flightId) {
		// TODO Auto-generated method stub
		try{begin();
		Query q=getSession().createQuery("from Flights where id=:id");
		q.setLong("id", flightId);
		Flights flightdel = (Flights) q.uniqueResult();
		System.out.println("id--" +flightdel.getId());
		 getSession().delete(flightdel);
		commit();
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		
		
	}
}

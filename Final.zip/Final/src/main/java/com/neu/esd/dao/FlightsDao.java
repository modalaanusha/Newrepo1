package com.neu.esd.dao;

import org.hibernate.HibernateException;

import com.neu.esd.pojo.Flights;
import com.neu.esd.pojo.User;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

public class FlightsDao extends DAO {

	public Flights createFlights(String srcCity, String destcity, String depDate, String arrDate)
	        throws Exception {
	    try {
	        begin();
	       
	        Flights flights=new Flights();
	        flights.setSrcCity(srcCity);
	        flights.setDestCity(destcity);
	        flights.setSrcCity(srcCity);
	        flights.setDestCity(destcity);
	        flights.setSrcCity(srcCity);
	        
	        
	        getSession().save(flights);
	        
	        commit();
	        return flights;
	    } catch (HibernateException e) {
	        rollback();
	        //throw new AdException("Could not create user " + username, e);
	        throw new Exception("Exception while creating user: " + e.getMessage());
	    }
	}
	
	public List<Flights> searchFlights(String srcCity, String destCity, Date depDate, Date arrDate)
	        throws Exception {
		List<Flights> flights=new ArrayList<Flights>();
		try{begin();
		Query q=getSession().createQuery("from Flights where srcCity=:srccity and"
				+ "destCity=:destcity and depDate=:depdate and arrDate=:arrdate");
		q.setString("srccity", srcCity);
        q.setString("destcity", destCity);
        q.setDate("depdate", depDate);
        q.setDate("arrdate", arrDate);
		flights=q.list();
		commit();
		
		}
		catch(Exception e){
			e.printStackTrace();
			rollback();
		}
		return flights;
	}
}

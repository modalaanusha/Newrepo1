package com.neu.esd.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.Person;
import com.neu.esd.pojo.User;

@Service
@Transactional
public interface PersonService {

	public User createUser(String username, String password, String firstname, String lastname)
	        throws Exception;
	
	public Person getUserByNameAndPassword(String userName, String password)
            throws Exception;
	
	public User getUser(String userName)
            throws Exception;
	
	public Person getUserbyName(String userName)
            throws Exception;
	
	public Admin getAdmin(String userName)
            throws Exception;
	
	public Admin createAdmin(String username, String password, String firstname, String lastname)
	        throws Exception;
	
	public User updateUserProfile(int id,User user )
	        throws Exception;
	
	public Boolean userCheck(Person person) throws Exception;
	
	
}

package com.neu.esd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.dao.PersonDao;
import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.User;

@Controller
public class RegistrationAdminController {

	@Autowired
    @Qualifier("adminValidator")
	RegistrationAdminValidator validator;
    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
	@RequestMapping(value= "/adminSignup", method = RequestMethod.POST)
   public String addAdmin(@ModelAttribute("admin")Admin admin,BindingResult result,Model model){
		validator.validate(admin, result);
		  if (result.hasErrors()) {
	           return "adminSignup";
	        }
     
   	try {
   		PersonDao personDao=new PersonDao();
   		//Boolean isValid=personDao.employeeCheck(user);
       	//if(!isValid){
       	//	model.addAttribute("error",true);
       //		return "usersignup";       	
       	//}
       	
   		personDao.createAdmin(admin.getUserName(), admin.getPassword(),
   				admin.getFirstName(), admin.getLastName());
   		System.out.println("inside rty");
   		
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          return "registrationsuccess";
       }
}

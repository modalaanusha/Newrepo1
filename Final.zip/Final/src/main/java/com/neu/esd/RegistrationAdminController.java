package com.neu.esd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neu.esd.pojo.Admin;
import com.neu.esd.pojo.User;
import com.neu.esd.service.PersonService;

@Controller
public class RegistrationAdminController {

	@Autowired
	PersonService perSer;
	
	@Autowired
	RegistrationAdminValidator validator;
	
    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
    @RequestMapping(value="/adminSignup", method=RequestMethod.GET)
	public String getAdminSignup(@ModelAttribute("admin") Admin admin, BindingResult result){
		return "adminSignup";
	}
    
	@RequestMapping(value= "/adminSignup", method = RequestMethod.POST)
   public String addAdmin(@ModelAttribute("admin")Admin admin,BindingResult result,Model model){
		validator.validate(admin, result);
		  if (result.hasErrors()) {
	           return "adminSignup";
	        }
     
   	try {
   		
   		//Boolean isValid=personDao.employeeCheck(user);
       	//if(!isValid){
       	//	model.addAttribute("error",true);
       //		return "usersignup";       	
       	//}
       	
   		perSer.createAdmin(admin.getUserName(), admin.getPassword(),
   				admin.getFirstName(), admin.getLastName());
   		System.out.println("inside rty");
   		
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          return "registrationSuccess";
       }
}

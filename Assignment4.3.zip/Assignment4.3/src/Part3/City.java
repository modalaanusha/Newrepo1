package Part3;

public class City {
    String name;
    String from;
    String to;
    String maxtemp;
    String mintemp;
    String humidity;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getMaxtemp() {
		return maxtemp;
	}
	public void setMaxtemp(String maxtemp) {
		this.maxtemp = maxtemp;
	}
	public String getMintemp() {
		return mintemp;
	}
	public void setMintemp(String mintemp) {
		this.mintemp = mintemp;
	}
	public String getHumidity() {
		return humidity;
	}
	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}
   
    
}

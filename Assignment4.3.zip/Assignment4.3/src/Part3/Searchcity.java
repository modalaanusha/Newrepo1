package Part3;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.tomcat.dbcp.dbcp2.Utils;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import com.sun.org.apache.xerces.internal.parsers.DOMParser;


import jdk.internal.org.xml.sax.InputSource;
import jdk.internal.org.xml.sax.SAXException;

/**
 * Servlet implementation class Searchcity
 */

public class Searchcity extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Search = request.getParameter("Citysearch");
		String url="https://api.openweathermap.org/data/2.5/weather?q="+Search+"&mode=xml&appid=4a4cc3a033664e25de637b08b74c6036";
		
			HttpClient httpclient = HttpClients.createDefault();
			HttpGet httpGet = new HttpGet(url);
			HttpResponse resp = httpclient.execute(httpGet);
			
			int statusCode = resp.getStatusLine().getStatusCode();
			 Document doc = null;
			 Todaydata td = new Todaydata();
			 td.setName(Search);
			        if (statusCode == 200 ){
			            HttpEntity entity = resp.getEntity();
			            String content = EntityUtils.toString(entity);
			            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			            try {
			                DocumentBuilder builder = factory.newDocumentBuilder();
			                doc = builder.parse(new ByteArrayInputStream(content.getBytes()));
                            Element root = doc.getDocumentElement();  
                            NodeList temps = root.getElementsByTagName("temperature"); 
                            for(int i=0; i<temps.getLength(); i++) { 
                            Element temp = (Element)temps.item(i); 
                            String max = temp.getAttribute("max");
                            String min = temp.getAttribute("min");
			                td.setMax(max);
			                td.setMin(min);
                            }
                            NodeList humdi = root.getElementsByTagName("humidity"); 
                            for(int i=0; i<humdi.getLength(); i++) { 
                            Element hu = (Element)humdi.item(i); 
                            String huval = hu.getAttribute("value");
                            td.setHumidity(huval+"%");
                            }
                            NodeList sun = root.getElementsByTagName("sun"); 
                            for(int i=0; i<sun.getLength(); i++) { 
                            Element su = (Element)sun.item(i); 
                            String rise = su.getAttribute("rise");
                            String set = su.getAttribute("set");
			                String[] riseparts = rise.split("T");
			                String date = riseparts[0];
			                String rise1 = riseparts[1];
			                td.setSunrise(rise1);
			                String[] setparts = set.split("T");
			                String set1 = setparts[1];
			                td.setSunset(set1);
			                String[] dateparts = date.split("-");
			                String date1 = dateparts[2]+"-"+dateparts[1]+"-"+dateparts[0];
			                td.setDate(date1);
			                }
                            request.setAttribute("today", td);
			            } catch (ParserConfigurationException e) {              
			                e.printStackTrace();
			            } catch (org.xml.sax.SAXException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
}
String url1 = "https://api.openweathermap.org/data/2.5/forecast?q="+Search+"&mode=xml&appid=4a4cc3a033664e25de637b08b74c6036";

HttpClient httpclient1 = HttpClients.createDefault();
HttpGet httpGet1 = new HttpGet(url1);
HttpResponse resp1 = httpclient1.execute(httpGet1);

int statusCod = resp.getStatusLine().getStatusCode();
 Document doc1 = null;
        if (statusCod == 200 ){
            HttpEntity entity1 = resp1.getEntity();
            String content1 = EntityUtils.toString(entity1);
            System.out.println(content1);
            DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
            try {
                DocumentBuilder builder1 = factory1.newDocumentBuilder();
                doc = builder1.parse(new ByteArrayInputStream(content1.getBytes()));
                Element root = doc.getDocumentElement();
                NodeList time = root.getElementsByTagName("time"); 
                ArrayList<City> CityList = new ArrayList<City>();
                for(int i=0; i<time.getLength(); i++) { 
                	City city = new City();
                Element time1 = (Element)time.item(i); 
                //from
                String from = time1.getAttribute("from");
                String[] frparts = from.split("T");
                String fromdate = frparts[0];
                String[] frdparts = fromdate.split("-");
                String fr = frdparts[2]+"-"+frdparts[1]+"-"+frdparts[0];
                String fromtime = frparts[1];
                city.setFrom("Date:"+fr+";Time:"+fromtime);
                
                String to = time1.getAttribute("to");
                String[] toparts = to.split("T");
                String todate = toparts[0];
                String[] toparts1 = todate.split("-");
                String tod = toparts1[2]+"-"+toparts1[1]+"-"+toparts1[0];
                String totime = toparts[1];
                city.setTo("Date:"+tod+";Time:"+totime);
                
                
                NodeList tempe = time1.getElementsByTagName("temperature");               
                for(int i1=0; i1<tempe.getLength(); i1++) {
                	Element temp1 = (Element)tempe.item(i1); 
                	String max1 = temp1.getAttribute("max");
                	String min1 = temp1.getAttribute("min");
                	System.out.println("maxtemp"+max1);
                	city.setMaxtemp(max1 +"Kelvin");
                	city.setMintemp(min1 +"Kelvin");
                }
                NodeList humi = time1.getElementsByTagName("humidity");
                for(int i2=0; i2<humi.getLength(); i2++) {
                	Element humid = (Element)humi.item(i2); 
                	String hvalue = humid.getAttribute("value");
                	city.setHumidity(hvalue +"%");
                }
                
                CityList.add(city);
                }
                request.setAttribute("CityList", CityList);
                request.getRequestDispatcher("/Execute.jsp").forward(request, response);
                }
catch (ParserConfigurationException e) {              
        e.printStackTrace();
    } catch (org.xml.sax.SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
            
        }
                
}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        
	}
}


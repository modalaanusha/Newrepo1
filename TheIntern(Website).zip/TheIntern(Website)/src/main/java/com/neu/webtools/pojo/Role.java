package com.neu.webtools.pojo;

public class Role {

}

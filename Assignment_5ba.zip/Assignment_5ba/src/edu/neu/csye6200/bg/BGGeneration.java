package edu.neu.csye6200.bg;

import java.util.ArrayList;

public class BGGeneration {

	
		public BGStem firstst;
		ArrayList<BGStem> bglist = new ArrayList<BGStem>();
		BGRule bgr = new BGRule();
		int level =0;

		public BGGeneration() {
			
		}
		public BGGeneration(int frWidth,int frHeight)
		{
	//Creates first stem when starting Generation based on frame size
		 firstst = new BGStem();
		 double[] startPt = {frWidth/2,frHeight-70};
		 double[] endPt = {frWidth/2,(frHeight-100)*0.6};
		 firstst.setStartPt(startPt);
		 firstst.setEndPt(endPt);
		 firstst.setLevel(0);
		 firstst.setLength(startPt[1]-endPt[1]);
		 bglist.add(firstst);
	    }
		
/*Creating Generations based on Previous Generation when calling from
Generationset*/
		public BGGeneration createGeneration(ArrayList<BGStem>
				bglistprevious,int level,int rule) {
	/*Creating New Generation instance for holding the next created 
	generation fetching it to Generationset*/
			BGGeneration bggennew = new BGGeneration();
	//Using Rule1
			if(rule == 1) {
			ArrayList<BGStem> bglisnew = bgr.rule1(bglistprevious, level);
			bggennew.setBglist(bglisnew);
			}
	//Using Rule2
			if(rule == 2) {
			ArrayList<BGStem> bglisnew = bgr.rule2(bglistprevious, level);
			bggennew.setBglist(bglisnew);
			}
    //Using Rule3
			if(rule == 3) {
				ArrayList<BGStem> bglisnew = bgr.rule3(bglistprevious, level);
				bggennew.setBglist(bglisnew);
				}
	//Using Rule4
			if(rule == 4) {
				ArrayList<BGStem> bglisnew = bgr.rule4(bglistprevious, level);
				bggennew.setBglist(bglisnew);
				}
			return bggennew;
		}

		public BGStem getFirstst() {
			return firstst;
		}

		public void setFirstst(BGStem firstst) {
			this.firstst = firstst;
		}


		public ArrayList<BGStem> getBglist() {
			return bglist;
		}

		public void setBglist(ArrayList<BGStem> bglist) {
			this.bglist = bglist;
		}

		public BGRule getBgr() {
			return bgr;
		}

		public void setBgr(BGRule bgr) {
			this.bgr = bgr;
		}

		public int getLevel() {
			return level;
		}

		public void setLevel(int level) {
			this.level = level;
		}

		

	
}

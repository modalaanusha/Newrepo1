package edu.neu.csye6200.bg;

import java.util.ArrayList;

public class BGStem {
	
	private double[] startPt;//Start Point
	private double[] endPt;// End Point
	private double length;//Length
	private double angle;//Angle
	private int level;//Level
	
	public BGStem( int len, double angle){
		this.length=len;
		this.angle= angle;
	}

	public BGStem() {
		
	}

	public double[] getStartPt() {
		return startPt;
	}

	public void setStartPt(double[] startPt) {
		this.startPt = startPt;
	}

	public double[] getEndPt() {
		return endPt;
	}

	public void setEndPt(double[] endPt) {
		this.endPt = endPt;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(double angle) {
		this.angle = angle;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	
	


	
}

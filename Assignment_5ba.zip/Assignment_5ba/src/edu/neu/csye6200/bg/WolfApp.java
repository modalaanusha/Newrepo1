package edu.neu.csye6200.bg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 * A Test application for the Wolfram Biological Growth application
 * @author MMUNSON
 */
public class WolfApp extends BGApp {

	private static Logger log = Logger.getLogger(WolfApp.class.getName());

	protected JPanel mainPanel = null;
	protected JPanel northPanel = null;
	protected JButton startBtn = null;
	protected JButton stopBtn = null;
	protected JButton contBtn = null;
    public BGCanvas bgPanel;
    public String gen = new String();
    public JTextField genNum = new JTextField();
    private int no = 1;
    
	public JComboBox combo=null;
	
    /**
     * Sample app constructor
     */
    public WolfApp() {
    	
    	frame.setSize(1000, 800); // initial Frame size
		frame.setTitle("WolfApp");
		bgPanel = new BGCanvas(frame.getWidth(),frame.getHeight());
		frame.add(getMainPanel(), BorderLayout.CENTER);
		menuMgr.createDefaultActions(); // Set up default menu items
		
    	showUI(); // Cause the Swing Dispatch thread to display the JFrame
    }
   
    /**
     * Create a main panel that will hold the bulk of our application display
     */
	@Override
	public JPanel getMainPanel() {
	
		mainPanel = new JPanel();
    	mainPanel.setLayout(new BorderLayout());
    	mainPanel.add(BorderLayout.NORTH,getNorthPanel());
    	
    	
    	mainPanel.add(BorderLayout.CENTER,bgPanel);
    	
    	return mainPanel;
	}
    
	/**
	 * Create a top panel that will hold control buttons
	 * @return
	 */
	
	
    public JPanel getNorthPanel() {
    	northPanel = new JPanel();
    	northPanel.setLayout(new FlowLayout());
    	northPanel.setSize(1000,100);
    	startBtn = new JButton("Start");
    	startBtn.addActionListener(this); // Allow the app to hear about button pushes
    	northPanel.add(startBtn);
    	
    	stopBtn = new JButton("Stop"); // Allow the app to hear about button pushes
    	stopBtn.addActionListener(this);
    	northPanel.add(stopBtn);
    	
    	contBtn = new JButton("Cont"); // Allow the app to hear about button pushes
    	contBtn.setEnabled(false);
    	contBtn.addActionListener(this);
    	northPanel.add(contBtn);
    	
    	String[] S={"Rule1","Rule2","Rule3","Rule4"};
		combo=new JComboBox(S);
		combo.setPreferredSize(new Dimension(200,27));
		combo.setLightWeightPopupEnabled(false);
		combo.addActionListener(this);

		northPanel.add(combo);
		
		genNum=new JTextField("10");
		
		
		genNum.setPreferredSize(new Dimension(50,25));
		
		genNum.addActionListener(this);		
		JLabel label1=new JLabel("No Of Generations:");
		northPanel.add(label1);
		northPanel.add(genNum);
    	return northPanel;
    }
    
    
    private void startBtnactionperformed(ActionEvent evt) {
		// TODO Auto-generated method stub
         System.out.println("numer" +no);
        log.info("gener" +gen);
        stopBtn.setEnabled(true);
        contBtn.setEnabled(false);
        gen = genNum.getText();
        System.out.println("Generations" +gen);
    	update(no, gen);
	}
    
    private void stopBtnactionperformed(ActionEvent evt) {
		// TODO Auto-generated method stub
    	contBtn.setEnabled(true);
    	 bgPanel.stop1();	
	}
    
    private void contBtnactionperformed(ActionEvent evt) {
		// TODO Auto-generated method stub
    	 bgPanel.cont();	
	}
    
	private void comboactionperformed(ActionEvent evt) {
		// TODO Auto-generated method stub
    	JComboBox combo = (JComboBox)evt.getSource();
        String Name = (String)combo.getSelectedItem();
        stopBtn.setEnabled(false);
        contBtn.setEnabled(false);
        int i=0;
        
        if(Name=="Rule1")
        {i=1;}
         
        else if(Name=="Rule2")
        {i=2;}
       
        else if(Name=="Rule3")
        {i=3;}
          
        else if(Name=="Rule4")
        {i=4;}
     
        no = i;
        
	}
    
	@Override
	public void actionPerformed(ActionEvent ae) {
		log.info("We received an ActionEvent " + ae.getActionCommand());
		log.info("source:::" +ae.getSource());
		if (ae.getActionCommand() == "Start") {
			System.out.println("Start pressed");
		startBtnactionperformed(ae);
		}else if (ae.getActionCommand() == "Stop") {
			System.out.println("Stop pressed");	
			stopBtnactionperformed(ae);
		}else if (ae.getActionCommand() == "Cont") {
			System.out.println("Continue pressed");	
			contBtnactionperformed(ae);
		}else if (ae.getActionCommand() == "comboBoxChanged") {
			System.out.println("Combo pressed");
			comboactionperformed(ae);
			System.out.println("number" +no);
		} 
	}

	
	@Override
	public void update(int rule,String genNo) {
		// TODO Auto-generated method stub
		int maxGens=0;
		try{
                    maxGens=Integer.parseInt(genNo); 
                }
		
		catch(NumberFormatException E){
			
			JOptionPane.showMessageDialog(null, "Please Enter a Correct Value!");
			return;
			
		}
		if(maxGens<0)
		{
			JOptionPane.showMessageDialog(null, "Please Enter a Positive  Value!");
			return;
		}
		if(maxGens>10)
		{
			int reply = JOptionPane.showConfirmDialog(null, " Max number of Rows is 1000\n", "Error!", JOptionPane.YES_NO_OPTION);
            if (reply == JOptionPane.YES_OPTION)
            {
                genNo ="10";
            }
            else{
                return;
            }
		bgPanel.startApp(no,genNo);
		}
		else{
System.out.println("no" +no);
System.out.println("gen" +genNo);
			bgPanel.startApp(no, genNo);
		}
	}
	
	@Override
	public void windowOpened(WindowEvent e) {
		log.info("Window opened");
	}

	@Override
	public void windowClosing(WindowEvent e) {	
		log.info("Window closing");
	}



	@Override
	public void windowClosed(WindowEvent e) {
		log.info("Window closed");
	}



	@Override
	public void windowIconified(WindowEvent e) {
		log.info("Window iconified");
	}



	@Override
	public void windowDeiconified(WindowEvent e) {	
		log.info("Window deiconified");
	}



	@Override
	public void windowActivated(WindowEvent e) {
		log.info("Window activated");
	}



	@Override
	public void windowDeactivated(WindowEvent e) {	
		log.info("Window deactivated");
	}
	
	/**
	 * Sample Wolf application starting point
	 * @param args
	 */
	public static void main(String[] args) {
		WolfApp wapp = new WolfApp();
		log.info("WolfApp started");
	}

	


}

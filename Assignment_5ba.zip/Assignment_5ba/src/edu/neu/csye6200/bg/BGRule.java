package edu.neu.csye6200.bg;

import java.util.ArrayList;

public class BGRule {
	int length;
	double angle;
	ArrayList<BGStem> bglist;
	int level = 0;
	public ArrayList<BGStem> calcNextgenStemsRule1(double[] endpt,double length,int level) {
    /*Calculating next corresponding two co-ordinates
     * for each previous generation co-ordinate
     * by creating two stems for every co-ordinate
     * of previous generation
     */
		bglist = new ArrayList<BGStem>();
		BGStem bg = new BGStem();
        BGStem bg1 = new BGStem();
		double len = length*0.6;
		double theta = 40;
		bg = calCoordinates(endpt,len,theta);
		bg.setLevel(level + 1);
		bglist.add(bg);
		theta = -theta*0.8;
		bg1 = calCoordinates(endpt, len, theta);
		bg1.setLevel(level + 1);
		bglist.add(bg1);
		return bglist;
	}
	
	public ArrayList<BGStem> calcNextgenStemsRule2(double[] endpt,double length,int level) {
		/*Calculating next corresponding three co-ordinates
	     * for each previous generation co-ordinate
	     * by creating three stems for every co-ordinate
	     * of previous generation
	     */
		bglist = new ArrayList<BGStem>();
		BGStem bg = new BGStem();
        BGStem bg1 = new BGStem();
        BGStem bg2 = new BGStem();
		double len = length*0.55;
		double theta = 120;
		bg = calCoordinates(endpt,len,theta);
		bg.setLevel(level + 1);
		bglist.add(bg);
		theta = -theta;
		bg1 = calCoordinates(endpt, len, theta);
		bg1.setLevel(level + 1);
		bglist.add(bg1);
		theta = 0;
		bg2 = calCoordinates(endpt, len, theta);
		bg2.setLevel(level + 1);
		bglist.add(bg2);
		return bglist;
	}
	
	public ArrayList<BGStem> calcNextgenStemsRule3(double[] endpt,double length,int level) {
		/*Calculating next corresponding three co-ordinates
	     * for each previous generation co-ordinate
	     * by creating three stems for every co-ordinate
	     * of previous generation
	     */
		bglist = new ArrayList<BGStem>();
		BGStem bg = new BGStem();
        BGStem bg1 = new BGStem();
        BGStem bg2 = new BGStem();
        BGStem bg3 = new BGStem();
		double len = length*0.6;
		double theta = 110;
		bg = calCoordinates(endpt,len,theta);
		bg.setLevel(level + 1);
		bglist.add(bg);
		theta = -theta*0.95;
		bg1 = calCoordinates(endpt, len, theta);
		bg1.setLevel(level + 1);
		bglist.add(bg1);
		theta = theta*0.4;
		bg2 = calCoordinates(endpt, len, theta);
		bg2.setLevel(level + 1);
		bglist.add(bg2);
		theta = -theta*0.7;
		bg3 = calCoordinates(endpt, len, theta);
		bg3.setLevel(level + 1);
		bglist.add(bg3);
		return bglist;
	}
	
	public ArrayList<BGStem> calcNextgenStemsRule4(double[] endpt,double length,int level) {
		/*Calculating next corresponding three co-ordinates
	     * for each previous generation co-ordinate
	     * by creating three stems for every co-ordinate
	     * of previous generation
	     */
		bglist = new ArrayList<BGStem>();
		BGStem bg = new BGStem();
        BGStem bg1 = new BGStem();
        BGStem bg2 = new BGStem();
        BGStem bg3 = new BGStem();
        
		double len = length*0.55;
		double theta = 75;
		bg = calCoordinates(endpt,len,theta);
		bg.setLevel(level + 1);
		bglist.add(bg);
		theta = -theta;
		bg1 = calCoordinates(endpt, len, theta);
		bg1.setLevel(level + 1);
		bglist.add(bg1);
		theta = theta*0.5;
		bg2 = calCoordinates(endpt, len, theta);
		bg2.setLevel(level + 1);
		bglist.add(bg2);
		theta = -theta;
		bg3 = calCoordinates(endpt, len, theta);
		bg3.setLevel(level + 1);
		bglist.add(bg3);
		
		return bglist;
	}
	
	public ArrayList<BGStem> rule1(ArrayList<BGStem> bglisPrevious,int level) {
		ArrayList<BGStem> bglisnewgen = new ArrayList<BGStem>();
/*Looping on every previous generation coordinate and 
 * calculating next generation points,Every co-ordinate will create
 * two corresponding co-ordinates in the next generation
 */
     for(int i=0; i<bglisPrevious.size();i++) {
    	 
      ArrayList<BGStem> bgl = calcNextgenStemsRule1(bglisPrevious.get(i).getEndPt(),
		   bglisPrevious.get(i).getLength(),level);
      bglisnewgen.add(bgl.get(0));
      bglisnewgen.add(bgl.get(1));
      }
     return bglisnewgen;
	 }
	
	
	public ArrayList<BGStem> rule2(ArrayList<BGStem> bglisPrevious,int level) {
		ArrayList<BGStem> bglisnewgen = new ArrayList<BGStem>();
/*Looping on every previous generation coordinate and 
 * calculating next generation points
 */
     for(int i=0; i<bglisPrevious.size();i++) {
    	  
      ArrayList<BGStem> bgl = calcNextgenStemsRule2(bglisPrevious.get(i).getEndPt(),
		   bglisPrevious.get(i).getLength(),level);
      bglisnewgen.add(bgl.get(0));
      bglisnewgen.add(bgl.get(1));
      bglisnewgen.add(bgl.get(2));
      
      }
     return bglisnewgen;
	 }
	
	public ArrayList<BGStem> rule3(ArrayList<BGStem> bglisPrevious,int level) {
		ArrayList<BGStem> bglisnewgen = new ArrayList<BGStem>();
/*Looping on every previous generation coordinate and 
 * calculating next generation points
 */
     for(int i=0; i<bglisPrevious.size();i++) {
      ArrayList<BGStem> bgl = calcNextgenStemsRule3(bglisPrevious.get(i).getEndPt(),
		   bglisPrevious.get(i).getLength(),level);
      bglisnewgen.add(bgl.get(0));
      bglisnewgen.add(bgl.get(1));
      bglisnewgen.add(bgl.get(2));
      bglisnewgen.add(bgl.get(3));
      }
     return bglisnewgen;
	 }
	
	public ArrayList<BGStem> rule4(ArrayList<BGStem> bglisPrevious,int level) {
		ArrayList<BGStem> bglisnewgen = new ArrayList<BGStem>();
/*Looping on every previous generation coordinate and 
 * calculating next generation points
 */
     for(int i=0; i<bglisPrevious.size();i++) {
      ArrayList<BGStem> bgl = calcNextgenStemsRule4(bglisPrevious.get(i).getEndPt(),
		   bglisPrevious.get(i).getLength(),level);
      bglisnewgen.add(bgl.get(0));
      bglisnewgen.add(bgl.get(1));
      bglisnewgen.add(bgl.get(2));
      bglisnewgen.add(bgl.get(3));
      }
     return bglisnewgen;
	 }

	
	private BGStem calCoordinates(double[] endPtprev, double len,
			double theta) {
		/*Calculating end point co-ordinates of next 
		 *generation by taking previous generation
		 * end point co-ordinates
		*/
		BGStem bg = new BGStem();
		
		double endPtx = endPtprev[0]+len*(Math.sin( Math.toRadians( theta )));
		double endPty = endPtprev[1]-len*(Math.cos( Math.toRadians( theta )));
		
		double[] endPtnew = {endPtx, endPty};
		bg.setEndPt(endPtnew);
		bg.setStartPt(endPtprev);
		bg.setLength(len);
		return bg;
	}
}

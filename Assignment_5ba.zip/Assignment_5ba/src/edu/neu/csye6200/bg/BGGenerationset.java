package edu.neu.csye6200.bg;

import java.util.ArrayList;

public class BGGenerationset {
	public BGGeneration bgGen;
	public int next;
	public ArrayList<BGGeneration> bgGenList;
	public int level;
	
	public BGGenerationset() {
		
	}
	
	public void CreateGeneration(int rule,int gen, int width, int height){
		bgGen = new BGGeneration(width,height);
		bgGenList = new ArrayList<BGGeneration>();
		bgGenList.add(bgGen);
		level = 0;
        /**Creating the generation from BGGeneration
         * by calling them multiple times(Generations you want)
         */
		while(level < gen) {
		BGGeneration bggennew = bgGenList.get(level).createGeneration
		(bgGenList.get(level).getBglist(),level,rule);
		bgGenList.add(bggennew);
		level++;
		}	
	}
	

	public BGGeneration getBgGen() {
		return bgGen;
	}


	public void setBgGen(BGGeneration bgGen) {
		this.bgGen = bgGen;
	}


	public ArrayList<BGGeneration> getBgGenList() {
		return bgGenList;
	}


	public void setBgGenList(ArrayList<BGGeneration> bgGenList) {
		this.bgGenList = bgGenList;
	}


	public int getNext() {
		return next;
	}


	public void setNext(int next) {
		this.next = next;
	}


	

	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}

	
	
}

package edu.neu.csye6200.bg;


import java.util.logging.Logger;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Line2D;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * A sample canvas that draws a rainbow of lines
 * @author MMUNSON
 */
public class BGCanvas extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private Logger log = Logger.getLogger(BGCanvas.class.getName());
    private int lineSize = 20;
    private Color col = null;
    private long counter = 0L;
    public int maxGen=0;
    public int ruleNum=0;
    private int width;
    private int height;
    public int times=-2;
    private BGGenerationset bgGenSet = null;
    public boolean done = false;
    public int i1 = 0;
    public Thread thread1 = null;
	private boolean isPaused = false;
    /**
     * CellAutCanvas constructor
     */
	public BGCanvas(int width, int height) {
		col = Color.WHITE;
		this.width=width;
		this.height=height;
		
	}

	/**
	 * The UI thread calls this method when the screen changes, or in response
	 * to a user initiated call to repaint();
	 */

	public void startApp(int rule,String genNum) {
		try{maxGen=Integer.parseInt(genNum);}
		catch(NumberFormatException e){}
		ruleNum=rule;
		bgGenSet = new BGGenerationset();
		bgGenSet.CreateGeneration(ruleNum, maxGen, width, height);
		done = false;
		i1 = 0;
		isPaused = false;
		Runnable run1 = new Runnable() {
	    public void run() {
		for(BGGeneration bgGen: bgGenSet.bgGenList) {
		look();
		repaint();
		try {
            Thread.sleep(1000);
         } catch (InterruptedException e) {
            e.printStackTrace();
         }
		i1++;
		}
	         }
		};
		thread1 = new Thread(run1);
		thread1.start();
	}
	
	/*Checking for start, stop button click and
	waiting the thread if stop button is clicked*/
	public synchronized void look(){
		   while(isPaused)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	//for stopping the thread
	public synchronized void stop1() {
		isPaused = true;
	}
	
	//continuing thread
    public synchronized void cont() {
		isPaused = false;
		notifyAll();
	}
	/**
	 * Draw the CA graphics panel
	 * @param g
	 */
	public void paint(Graphics g) {
		
		Graphics2D g2d = (Graphics2D) g;
		Dimension size = getSize();
		
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, size.width, size.height);
		
		g2d.setColor(Color.RED);
		g2d.drawString("Anusha Modala", 10, 15);
		
		int i = 0;

		if(bgGenSet != null) {
			     for(int i2=0; i2 < i1; i2++) {
			     BGGeneration bggen = bgGenSet.getBgGenList().get(i2);
			     for(BGStem stem: bggen.getBglist()) {
	   			   int redVal = validColor(155-i*5);
	   			   int greenVal = validColor(i*5);
	   			   int blueVal = validColor((i*5)-(i*5));
	   			   col = new Color(redVal, greenVal, blueVal);
	    		  Shape l = new Line2D.Double(stem.getStartPt()[0], stem.getStartPt()[1],
	    			stem.getEndPt()[0], stem.getEndPt()[1]);
	    		  g2d.setColor(col);
	    		  g2d.draw(l);
	    		  i++;
	    	     }
			     }
		}
		}
		
		
	
	
	
	/*
	 * A local routine to ensure that the color value is in the 0 to 255 range.
	 */
	private int validColor(int colorVal) {
		if (colorVal > 255)
			colorVal = 255;
		if (colorVal < 0)
			colorVal = 0;
		return colorVal;
	}
	

	/**
	 * A convenience routine to set the color and draw a line
	 * @param g2d the 2D Graphics context
	 * @param startx the line start position on the x-Axis
	 * @param starty the line start position on the y-Axis
	 * @param endx the line end position on the x-Axis
	 * @param endy the line end position on the y-Axis
	 * @param color the line color
	 */
	private void paintLine(Graphics2D g2d, int startx, int starty, int endx, int endy, Color color) {
		g2d.setColor(color);
		g2d.drawLine(startx, starty, endx, endy);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		times++;
	}

	
}


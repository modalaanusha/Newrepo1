package Part3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



/**
 * Servlet implementation class Nytimes
 */

public class Nytimes extends HttpServlet {
	
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CloseableHttpClient client = HttpClients.createDefault();
		String url="https://api.nytimes.com/svc/search/v2/articlesearch.json?format=json&api-key=175f09d849cc4e278c5b9f2000fefe29";
				
		   HttpGet get=new HttpGet(url);
		
		    	            HttpClient client1 = HttpClients.createDefault();
		    	            ResponseHandler<String> responseHandler=new BasicResponseHandler();
		    	            String responseBody = client1.execute(get, responseHandler);
		    	            try {
								JSONObject resp=new JSONObject(responseBody);
								System.out.println(resp);
								JSONObject respos = resp.getJSONObject("response"); // get data object
								JSONObject meta =  respos.getJSONObject("meta");
								int hits = meta.getInt("hits"); // get the name from data.
								System.out.println(hits);
								ArrayList<Docs> Doclist= new ArrayList<Docs>();
								JSONArray docsarr =  (JSONArray)respos.get("docs");
							    
								ArrayList<Docs> docli = new ArrayList<Docs>();
				    	
								for(int i =0; i < docsarr.length(); i++)
								  {
								    JSONObject J1 = docsarr.getJSONObject(i);
								    String web_url = J1.getString("web_url");
								    String snippet = J1.getString("snippet"); 
								   // String blog = J1.getString("blog"); 
								    String source = J1.getString("source"); 
								   // String multimedia = J1.getString("multimedia"); 
								   String main = J1.getJSONObject("headline").getString("main");
								   // String keywords = J1.getString("keywords"); 
								    String pub_date = J1.getString("pub_date"); 
								  //  String document_type = J1.getString("document_type"); 
								  //  String new_desk = J1.getString("new_desk"); 
								    String byline = J1.getJSONObject("byline").getString("original"); 
								    String type_of_material = J1.getString("type_of_material"); 
								    String _id = J1.getString("_id"); 
								  int word_count = J1.getInt("word_count"); 
								 //   String score = J1.getString("score"); 
								    String uri = J1.getString("uri");
								    
								    Docs dc = new Docs();
								    dc.setBy_line(byline);
								  //  dc.setBlog(blog);
								  //  dc.setDoc_typ(document_type);
								    dc.setHeadline(main);
								    dc.setId(_id);
								  //  dc.setScore(score);
								    dc.setSnippet(snippet);
								    dc.setPub_date(pub_date);
								    dc.setSource(source);
								    dc.setUri(uri);
								   dc.setWeb_url(web_url);
								    dc.setTom(type_of_material);
								  // dc.setNew_des(new_desk);
								    dc.setWord_Cnt(word_count);
								    
								    docli.add(dc);
								    
								  }
							    	
								request.setAttribute("doclist", docli);
		
		request.getRequestDispatcher("/Execute.jsp").forward(request, response);
							
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Search = request.getParameter("NYTimessearch");
		CloseableHttpClient client = HttpClients.createDefault();
		String url="https://api.nytimes.com/svc/search/v2/articlesearch.json?query="+ Search +"&format=json&api-key=175f09d849cc4e278c5b9f2000fefe29";
				
		   HttpGet get=new HttpGet(url);
		
		    	            HttpClient client1 = HttpClients.createDefault();
		    	            ResponseHandler<String> responseHandler=new BasicResponseHandler();
		    	            String responseBody = client1.execute(get, responseHandler);
		    	            try {
								JSONObject resp=new JSONObject(responseBody);
								System.out.println(resp);
								JSONObject respos = resp.getJSONObject("response"); // get data object
								JSONObject meta =  respos.getJSONObject("meta");
								int hits = meta.getInt("hits"); // get the name from data.
								System.out.println(hits);
								ArrayList<Docs> Doclist= new ArrayList<Docs>();
								JSONArray docsarr =  (JSONArray)respos.get("docs");
							    
								ArrayList<Docs> docli = new ArrayList<Docs>();
				    	
								for(int i =0; i < docsarr.length(); i++)
								  {
								    JSONObject J1 = docsarr.getJSONObject(i);
								    String web_url = J1.getString("web_url");
								    String snippet = J1.getString("snippet"); 
								   // String blog = J1.getString("blog"); 
								    String source = J1.getString("source"); 
								   
								   String main = J1.getJSONObject("headline").getString("main");
								    
								    String pub_date = J1.getString("pub_date"); 
								  
								    String type_of_material = J1.getString("type_of_material"); 
								    String _id = J1.getString("_id"); 
								    String uri = null;
								    String byline = null;
								    try {
								    uri = J1.getString("uri");
								    byline = J1.getJSONObject("byline").getString("original"); 
								    }catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}		
								  int word_count = J1.getInt("word_count"); 
								 //   String score = J1.getString("score"); 
								  
								    
								    Docs dc = new Docs();
								   dc.setBy_line(byline);
								    dc.setHeadline(main);
								    dc.setId(_id);
								    dc.setSnippet(snippet);
								    dc.setPub_date(pub_date);
								    dc.setSource(source);
									dc.setUri(uri);
								   dc.setWeb_url(web_url);
								    dc.setTom(type_of_material);
								    dc.setWord_Cnt(word_count);
								    
								    docli.add(dc);
								    
								  }
							    	
								request.setAttribute("doclist", docli);
		
		request.getRequestDispatcher("/Execute1.jsp").forward(request, response);
							
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}			
	}

}
